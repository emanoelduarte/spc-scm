## Requisitos

* PHP 8.3 ou superior;
* MySQL 8.0 ou superior;
* Composer;

## Como rodar o projeto baixado
Duplicar o arquivo ".env.exemple" e renomear para ".env"<br>
Alterar no arquivo .env as credênciais do banco de dados.<br>
Criar o banco de dados com a COLLACTION "utf8mb4_unicode_ci"<br>
Alterar no arquivo .env o endereço da aplicação na variável de ambiente URL_ADM

Instalar as dependências.
```
composer install
```
Executar as migrations.
```
vendor/bin/phinx migrate -c database/phinx.php
```
Executar as seed
```
vendor/bin/phinx seed:run -c database/phinx.php
```
Instalar a biblioteca para validar o formulário
```
composer require "rakit/validation"
```
Instalar a biblioteca gerenciar variáveis de ambiente
```
composer require vlucas/phpdotenv
```
Acessar o projeto: [Acessar](http://localhost/spcscm/)


## Sequencia para criar o projeto
Criar o arquivo composer.jason com a instrução básica
```
composer init
```
Instalar a dependência Monolo, biblioteca PHP que permite criar arquivo de log.
```
composer require monolog/monolog
```
Instalar a biblioteca gerenciar variáveis de ambiente
```
composer require vlucas/phpdotenv
```
Instalar a biblioteca para criar/executar migrations e seed.
```
composer require robmorgan/phinx
```
Criar arquivo "phinx.php" com as configurações e alterar as mesmas
```
vendor/bin/phinx init -f php
```

Testar as configurações
```
vendor/bin/phinx test
```

Criar o diretório database.
```
mkdir database/
```

Criar o diretório para migrations.
```
mkdir database/migrations/
```

Criar a migrations.
```
vendor/bin/phinx create AdmsDamanUsers -c database/phinx.php
```

Executar as migrations.
```
vendor/bin/phinx migrate -c database/phinx.php
```
Executar um rollback na ultima migration - reverter alterações realizadas
```
vendor/bin/phinx rollback -c database/phinx.php
```

Criar o diretório para seed
```
mkdir database/seeds/
```
Criar seed (arquivo)
```
vendor/bin/phinx seed:create AddAdmsDamanUsers -c database/phinx.php
```
Executar as seeds
```
vendor/bin/phinx seed:run -c database/phinx.php
```
Instalar a biblioteca para enviar e-mail com php
```
composer require phpmailer/phpmailer
```
Instalar a biblioteca domPdf
```
composer require dompdf/dompdf
```
Instalar a biblioteca responsável pela comunicação com a SEFAZ e operações relacionadas à NF-e:
```
composer require nfephp-org/sped-nfe
```

### Instalar biblioteca para geração do DANFE
Verificar se as extensões PHP necessárias estão habilitadas: 
````
php -m | findstr /I "dom gd mbstring"
```
Verificar a versão do pacote comum utilizado pelo NFePHP:
```
composer show nfephp-org/sped-common
```
Instalar a biblioteca responsável pela geração de DANFE e outros documentos auxiliares do SPED:
```
composer require nfephp-org/sped-da:^1.1
```
Instalar a biblioteca do php responsável por geração criação de arquivos de planilhas para gerar o relatório
```
composer require phpoffice/phpspreadsheet
```
### Como Usar o git
Baixar os arquivos do Git.
```
git clone --branch <branch_name> <repository_url> .
```

Definir as configurações do usuario.
```
git config --local user.name <Emanoel>
```
```
git config --local user.email <emanoel.c.duarte@hotmail.com>
```

Verificar a branch que estamos trabalhando
```
git branch
```

## Lista de erros 
001 - DbConnection.php - Erro de conexão com o banco de dados
002 - LoadPageAdm.php - Página não encontrada
003 - LoadPageAdm.php - Controller não encontrada
004 - LoadPageAdm.php - Método não encontrada
005 - LoadViewService.php - Falha em encontrar a View
006 - LoadPageAdm.php - Usuário não logado tentou acessar paágina privada

