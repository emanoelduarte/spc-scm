<?php

declare(strict_types=1);

use Phinx\Seed\AbstractSeed;

class AddAdmsDamanBudgetsSeeder extends AbstractSeed
{
    /**
     * Cadastra orçamentos de teste na tabela adms_daman_budgets.
     *
     * @return void
     */
    public function run(): void
    {
        // Variável para receber os dados a serem inseridos
        $data = [];

        // Orçamentos que devem ser cadastrados
        $budgets = [
            [
                'adms_daman_project_id' => 1,
                'total_budget' => 100000.00,
                'type' => 'approved',
                'created_by' => 1,
                'approved_by' => 1,
            ],
        ];

        // Percorrer os orçamentos
        foreach ($budgets as $budget) {

            // Verifica se já existe orçamento para a obra
            $existingRecord = $this->query(
                'SELECT id FROM adms_daman_budgets
                 WHERE adms_daman_project_id = :project_id',
                [
                    'project_id' => $budget['adms_daman_project_id']
                ]
            )->fetch();

            // Se não existir, adiciona ao array
            if (!$existingRecord) {
                $data[] = [
                    'adms_daman_project_id' => $budget['adms_daman_project_id'],
                    'total_budget' => $budget['total_budget'],
                    'type' => $budget['type'],
                    'created_by' => $budget['created_by'],
                    'approved_by' => $budget['approved_by'],
                    'approved_at' => date("Y-m-d H:i:s"),
                    'created_at' => date("Y-m-d H:i:s"),
                ];
            }
        }

        // Inserir somente se houver registros
        if (!empty($data)) {
            $table = $this->table('adms_daman_budgets');
            $table->insert($data)->save();
        }
    }
}
