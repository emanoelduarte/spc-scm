<?php

declare(strict_types=1);

use Phinx\Seed\AbstractSeed;

class AddAdmsDamanStagesSeeder extends AbstractSeed
{
    /**
     * Cadastra as etapas iniciais na tabela adms_daman_stages
     * caso ainda não existam.
     *
     * @return void
     */
    public function run(): void
    {
        // Array que receberá somente os registros
        // que ainda não existem no banco
        $data = [];


        // Etapas padrões disponíveis inicialmente
        $stages = [

            [
                'code' => '01',
                'name' => 'Serviços Preliminares',
            ],

            [
                'code' => '02',
                'name' => 'Fundação',
            ],

            [
                'code' => '03',
                'name' => 'Estrutura',
            ],

            [
                'code' => '04',
                'name' => 'Alvenaria',
            ],

            [
                'code' => '05',
                'name' => 'Cobertura',
            ],

            [
                'code' => '06',
                'name' => 'Instalações Hidráulicas',
            ],

            [
                'code' => '07',
                'name' => 'Instalações Elétricas',
            ],

            [
                'code' => '08',
                'name' => 'Revestimentos',
            ],

            [
                'code' => '09',
                'name' => 'Esquadrias',
            ],

            [
                'code' => '10',
                'name' => 'Pintura',
            ],

            [
                'code' => '11',
                'name' => 'Acabamento',
            ],

            [
                'code' => '12',
                'name' => 'Paisagismo',
            ],

            [
                'code' => '13',
                'name' => 'Limpeza Final',
            ],
        ];


        // Percorrer todas as etapas
        foreach ($stages as $stage) {

            // Verificar se a etapa já existe pelo código
            $existingRecord = $this->query(
                'SELECT id
                 FROM adms_daman_stages
                 WHERE code = :code',
                [
                    'code' => $stage['code']
                ]
            )->fetch();


            // Caso ainda não exista, adicionar ao array
            if (!$existingRecord) {

                $data[] = [

                    'code' => $stage['code'],

                    'name' => $stage['name'],

                    'status' => 1,

                    'created_at' => date("Y-m-d H:i:s"),
                ];
            }
        }


        // Inserir somente caso existam novos registros
        if (!empty($data)) {

            // Recuperar a tabela
            $adms_daman_stages =
                $this->table('adms_daman_stages');

            // Inserir os registros
            $adms_daman_stages
                ->insert($data)
                ->save();
        }
    }
}
