<?php

declare(strict_types=1);

use Phinx\Seed\AbstractSeed;

class AddAdmsDamanBudgetStagesSeeder extends AbstractSeed
{
    public function run(): void
    {
        // Array que receberá os registros que serão inseridos
        $data = [];


        // =====================================================
        // LOCALIZAR O ORÇAMENTO DE TESTE
        // =====================================================

        $budget = $this->query("
            SELECT id
            FROM adms_daman_budgets
            WHERE adms_daman_project_id = 1
            LIMIT 1
        ")->fetch();


        // Caso o orçamento não exista,
        // não há como cadastrar suas etapas
        if (!$budget) {
            return;
        }


        $budgetId = (int) $budget['id'];


        // =====================================================
        // ETAPAS QUE SERÃO VINCULADAS AO ORÇAMENTO
        // =====================================================

        $budgetStages = [

            [
                'stage_code' => '02',
                'budget_value' => 20000.00,
                'sort_order' => 1,
            ],

            [
                'stage_code' => '03',
                'budget_value' => 30000.00,
                'sort_order' => 2,
            ],

            [
                'stage_code' => '04',
                'budget_value' => 25000.00,
                'sort_order' => 3,
            ],

        ];


        // =====================================================
        // PERCORRER AS ETAPAS
        // =====================================================

        foreach ($budgetStages as $budgetStage) {

            // Localizar a etapa mestre através do código
            $stage = $this->query(
                "
                    SELECT id
                    FROM adms_daman_stages
                    WHERE code = :code
                    LIMIT 1
                ",
                [
                    'code' => $budgetStage['stage_code']
                ]
            )->fetch();


            // Caso a etapa não exista no cadastro mestre,
            // simplesmente pula para a próxima
            if (!$stage) {
                continue;
            }


            $stageId = (int) $stage['id'];


            // =================================================
            // VERIFICAR SE O VÍNCULO JÁ EXISTE
            // =================================================

            $existingRecord = $this->query(
                "
                    SELECT id
                    FROM adms_daman_budget_stages
                    WHERE adms_daman_budget_id = :budget_id
                    AND adms_daman_stage_id = :stage_id
                    LIMIT 1
                ",
                [
                    'budget_id' => $budgetId,
                    'stage_id' => $stageId
                ]
            )->fetch();


            // Cadastrar somente se ainda não existir
            if (!$existingRecord) {

                $data[] = [

                    'adms_daman_budget_id' => $budgetId,

                    'adms_daman_stage_id' => $stageId,

                    'budget_value' =>
                        $budgetStage['budget_value'],

                    'sort_order' =>
                        $budgetStage['sort_order'],

                    'status' => 1,

                    'created_at' =>
                        date('Y-m-d H:i:s'),

                ];
            }
        }


        // =====================================================
        // INSERIR
        // =====================================================

        if (!empty($data)) {

            $this->table(
                'adms_daman_budget_stages'
            )
                ->insert($data)
                ->save();
        }
    }
}