<?php

declare(strict_types=1);

use Phinx\Seed\AbstractSeed;

class AddAdmsDamanOrderItemAllocationsSeeder extends AbstractSeed
{
    /**
     * Seed reservada para apropriações orçamentárias.
     *
     * As apropriações dependem de itens reais existentes em
     * adms_daman_order_items e somente serão utilizadas durante
     * a integração entre pedidos e orçamento.
     *
     * @return void
     */
    public function run(): void
    {
        // Nenhum registro inicial.
        // Esta tabela será populada através do fluxo de pedidos.
    }
}
