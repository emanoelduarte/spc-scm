<?php

declare(strict_types=1);

use Phinx\Seed\AbstractSeed;

class AddAdmsDamanBudgetItemsSeeder extends AbstractSeed
{
    /**
     * Cadastra itens de teste nas etapas do orçamento.
     *
     * Os itens são vinculados à etapa específica do orçamento
     * através da tabela adms_daman_budget_stages.
     *
     * @return void
     */
    public function run(): void
    {
        // Array que receberá somente os registros
        // que ainda não existem no banco de dados.
        $data = [];


        // =====================================================
        // LOCALIZAR O ORÇAMENTO DE TESTE
        // =====================================================
        //
        // Neste Seed estamos utilizando a obra ID 1.
        //
        // Primeiro localizamos o orçamento pertencente
        // a essa obra.
        //
        $budget = $this->query(
            'SELECT id
             FROM adms_daman_budgets
             WHERE adms_daman_project_id = :project_id
             LIMIT 1',
            [
                'project_id' => 1
            ]
        )->fetch();


        // Caso não exista orçamento para essa obra,
        // não há como cadastrar os itens.
        if (!$budget) {
            return;
        }


        // ID do orçamento localizado.
        $budgetId = (int) $budget['id'];


        // =====================================================
        // ITENS DO ORÇAMENTO
        // =====================================================
        //
        // stage_code corresponde ao código cadastrado na
        // tabela mestre adms_daman_stages.
        //
        // Exemplo:
        //
        // 02 = Fundação
        // 03 = Estrutura
        // 04 = Alvenaria
        //
        // measurement_unit_id deve corresponder aos IDs
        // existentes em adms_daman_measurement_units.
        //
        $items = [


            // =================================================
            // FUNDAÇÃO
            // Etapa mestre: código 02
            // =================================================

            [
                'stage_code' => '02',
                'code' => '02.01',
                'description' => 'Cimento',
                'measurement_unit_id' => 1,
                'quantity' => 100,
                'unit_price' => 50.00,
                'budget_value' => 5000.00,
                'sort_order' => 1,
            ],

            [
                'stage_code' => '02',
                'code' => '02.02',
                'description' => 'Ferro',
                'measurement_unit_id' => 6,
                'quantity' => 875,
                'unit_price' => 8.00,
                'budget_value' => 7000.00,
                'sort_order' => 2,
            ],

            [
                'stage_code' => '02',
                'code' => '02.03',
                'description' => 'Areia',
                'measurement_unit_id' => 11,
                'quantity' => 32.50,
                'unit_price' => 92.30,
                'budget_value' => 3000.00,
                'sort_order' => 3,
            ],

            [
                'stage_code' => '02',
                'code' => '02.04',
                'description' => 'Brita',
                'measurement_unit_id' => 11,
                'quantity' => 25,
                'unit_price' => 195.00,
                'budget_value' => 5000.00,
                'sort_order' => 4,
            ],


            // =================================================
            // ESTRUTURA
            // Etapa mestre: código 03
            // =================================================

            [
                'stage_code' => '03',
                'code' => '03.01',
                'description' => 'Concreto',
                'measurement_unit_id' => 11,
                'quantity' => 100,
                'unit_price' => 150.00,
                'budget_value' => 15000.00,
                'sort_order' => 1,
            ],

            [
                'stage_code' => '03',
                'code' => '03.02',
                'description' => 'Aço',
                'measurement_unit_id' => 6,
                'quantity' => 1000,
                'unit_price' => 10.00,
                'budget_value' => 10000.00,
                'sort_order' => 2,
            ],

            [
                'stage_code' => '03',
                'code' => '03.03',
                'description' => 'Formas',
                'measurement_unit_id' => 1,
                'quantity' => 1,
                'unit_price' => 5000.00,
                'budget_value' => 5000.00,
                'sort_order' => 3,
            ],


            // =================================================
            // ALVENARIA
            // Etapa mestre: código 04
            // =================================================

            [
                'stage_code' => '04',
                'code' => '04.01',
                'description' => 'Tijolo',
                'measurement_unit_id' => 1,
                'quantity' => 10000,
                'unit_price' => 1.50,
                'budget_value' => 15000.00,
                'sort_order' => 1,
            ],

            [
                'stage_code' => '04',
                'code' => '04.02',
                'description' => 'Argamassa',
                'measurement_unit_id' => 1,
                'quantity' => 200,
                'unit_price' => 50.00,
                'budget_value' => 10000.00,
                'sort_order' => 2,
            ],

        ];


        // =====================================================
        // PERCORRER TODOS OS ITENS
        // =====================================================

        foreach ($items as $item) {


            // =================================================
            // LOCALIZAR A ETAPA DENTRO DO ORÇAMENTO
            // =================================================
            //
            // Antes o código da etapa estava diretamente em:
            //
            // adms_daman_budget_stages.code
            //
            // Agora o código pertence à tabela mestre:
            //
            // adms_daman_stages.code
            //
            // Por isso precisamos fazer o JOIN entre:
            //
            // adms_daman_budget_stages
            //            +
            // adms_daman_stages
            //
            $stage = $this->query(
                'SELECT
                    adbs.id

                 FROM adms_daman_budget_stages AS adbs

                 INNER JOIN adms_daman_stages AS ads
                    ON ads.id = adbs.adms_daman_stage_id

                 WHERE adbs.adms_daman_budget_id = :budget_id
                 AND ads.code = :stage_code

                 LIMIT 1',
                [
                    'budget_id' => $budgetId,
                    'stage_code' => $item['stage_code'],
                ]
            )->fetch();


            // Caso a etapa não esteja vinculada a esse orçamento,
            // pula o item e continua para o próximo.
            if (!$stage) {
                continue;
            }


            // ID da etapa específica dentro deste orçamento.
            //
            // Importante:
            // este NÃO é o ID da tabela mestre adms_daman_stages.
            //
            // É o ID de adms_daman_budget_stages.
            $budgetStageId = (int) $stage['id'];


            // =================================================
            // VERIFICAR SE O ITEM JÁ EXISTE
            // =================================================
            //
            // Verificamos usando:
            //
            // etapa do orçamento + código do item
            //
            // Isso permite que diferentes etapas tenham
            // códigos próprios sem duplicar um item dentro
            // da mesma etapa.
            //
            $existingRecord = $this->query(
                'SELECT id
                 FROM adms_daman_budget_items
                 WHERE budget_stage_id = :budget_stage_id
                 AND code = :code
                 LIMIT 1',
                [
                    'budget_stage_id' => $budgetStageId,
                    'code' => $item['code'],
                ]
            )->fetch();


            // =================================================
            // PREPARAR ITEM PARA INSERÇÃO
            // =================================================
            //
            // Somente adicionamos ao array caso ainda
            // não exista no banco.
            //
            if (!$existingRecord) {

                $data[] = [

                    // Etapa específica deste orçamento
                    'budget_stage_id' => $budgetStageId,

                    // Código do item
                    'code' => $item['code'],

                    // Descrição
                    'description' => $item['description'],

                    // Unidade de medida
                    'adms_daman_measurement_units_id'
                        => $item['measurement_unit_id'],

                    // Quantidade orçada
                    'quantity' => $item['quantity'],

                    // Valor unitário
                    'unit_price' => $item['unit_price'],

                    // Valor total orçado para o item
                    'budget_value' => $item['budget_value'],

                    // Ordem dentro da etapa
                    'sort_order' => $item['sort_order'],

                    // Item ativo
                    'status' => 1,

                    // Data de criação
                    'created_at' => date('Y-m-d H:i:s'),
                ];
            }
        }


        // =====================================================
        // INSERIR OS REGISTROS
        // =====================================================
        //
        // Somente executamos o INSERT caso exista pelo menos
        // um novo item para cadastrar.
        //
        if (!empty($data)) {

            $table = $this->table(
                'adms_daman_budget_items'
            );

            $table
                ->insert($data)
                ->save();
        }
    }
}