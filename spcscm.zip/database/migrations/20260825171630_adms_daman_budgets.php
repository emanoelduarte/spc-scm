<?php

declare(strict_types=1);

use Phinx\Migration\AbstractMigration;

/**
 * Esta tabela, tem o dever de representar a estrtura da de orçamento de cada obra, para gerenciar cada uma delas.
 */
final class AdmsDamanBudgets extends AbstractMigration
{
    public function up(): void
    {
        // Acessa o if se a tabela adms_daman_budgets existir
        if (!$this->hasTable('adms_daman_budgets')) {

            // Define as colunas da tabela
            $table = $this->table('adms_daman_budgets');

            $table
                ->addColumn('adms_daman_project_id', 'integer', ['null' => false, 'signed' => false])
                ->addForeignKey('adms_daman_project_id', 'adms_daman_projects', 'id', ['delete' => 'CASCADE', 'update' => 'CASCADE'])

                ->addColumn('total_budget', 'decimal', ['precision' => 10, 'scale' => 2, 'null' => true])

                ->addColumn('type', 'enum', [
                    'values' => ['draft', 'approved', 'inactive'],
                    'default' => 'draft',
                    'null' => false
                ])

                // Coluna de controle de quem criou o orçamento
                ->addColumn('created_by', 'integer', ['null' => false, 'signed' => false])
                ->addForeignKey('created_by', 'adms_daman_users', 'id', ['delete' => 'RESTRICT', 'update' => 'CASCADE'])

                // Coluna de controle de quem aprovou o orçamento
                ->addColumn('approved_by', 'integer', ['null' => true, 'signed' => false])
                ->addForeignKey('approved_by', 'adms_daman_users', 'id', ['delete' => 'RESTRICT', 'update' => 'CASCADE'])

                // Coluna de data da aprovação do orçamento
                ->addColumn('approved_at', 'timestamp', ['null' => true])

                ->addColumn('created_at', 'timestamp', ['null' => false])
                ->addColumn('updated_at', 'timestamp', ['null' => true])

                ->create();
        }
    }

    /**
     * Metodo down() para reverter a migração (caso necessário)
     */
    public function down(): void
    {
        // Apagar a tabela adms_daman_budgets
        $this->table('adms_daman_budgets')->drop()->save();
    }
}
