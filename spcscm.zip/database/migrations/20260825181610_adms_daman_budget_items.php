<?php

declare(strict_types=1);

use Phinx\Migration\AbstractMigration;

/**
 * Esta migration é responsável por criar a tabela adms_daman_budget_items, que representa os itens do orçamento de cada obra. {Materiais, Mão de Obra, Equipamentos, etc.}
 */
final class AdmsDamanBudgetItems extends AbstractMigration
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * https://book.cakephp.org/phinx/0/en/migrations.html#the-change-method
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function up(): void
    {
        // Acessa o if se a tabela adms_daman_budget_items existir
        if (!$this->hasTable('adms_daman_budget_items')) {

            // Definir as colunas da tabela
            $table = $this->table('adms_daman_budget_items');

            $table->addColumn('budget_stage_id', 'integer', ['null' => false, 'signed' => false])
                ->addForeignKey('budget_stage_id', 'adms_daman_budget_stages', 'id', ['delete' => 'CASCADE', 'update' => 'CASCADE'])

                ->addColumn('code', 'string', ['limit' => 50, 'null' => false, 'comment' => 'Código identificador do item dentro da etapa do orçamento'])

                // Descrição do item
                ->addColumn('description', 'string', ['null' => false, 'comment' => 'Descrição detalhada do item do orçamento'])

                // unidade de medida do item (ex: m², m³, un, kg, etc.)
                ->addColumn('adms_daman_measurement_units_id', 'integer', ['null' => false, 'signed' => false])
                ->addForeignKey('adms_daman_measurement_units_id', 'adms_daman_measurement_units', 'id', ['delete' => 'CASCADE', 'update' => 'CASCADE'])

                ->addColumn('quantity', 'decimal', ['precision' => 10, 'scale' => 2, 'null' => true])

                ->addColumn('unit_price', 'decimal', ['precision' => 10, 'scale' => 2, 'null' => true])

                ->addColumn('budget_value', 'decimal', ['precision' => 10, 'scale' => 2, 'null' => true, 'comment' => 'Valor do orçamento para a etapa'])

                ->addColumn('sort_order', 'integer', ['null' => false, 'signed' => false, 'comment' => 'Ordem de classificação da etapa do orçamento'])

                ->addColumn('status', 'tinyinteger', ['limit' => 1, 'null' => false, 'default' => 1, 'comment' => 'Status da etapa do orçamento: 1 - Ativo, 0 - Inativo'])

                ->addColumn('created_at', 'timestamp', ['null' => false])
                ->addColumn('updated_at', 'timestamp', ['null' => true])

                ->create();
        }
    }

    /**
     * Metodo down() para reverter a migração (caso necessário)
     */
    public function down(): void
    {
        // Apagar a tabela adms_daman_budget_items
        $this->table('adms_daman_budget_items')->drop()->save();
    }
}
