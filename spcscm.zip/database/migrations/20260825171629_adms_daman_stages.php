<?php

declare(strict_types=1);

use Phinx\Migration\AbstractMigration;

/**
 * Esta migration é responsável por criar a tabela adms_daman_stages,
 * que representa o cadastro mestre das etapas disponíveis para os orçamentos.
 *
 * Exemplos:
 * Fundação, Estrutura, Alvenaria, Cobertura, Instalações, Acabamento, etc.
 */
final class AdmsDamanStages extends AbstractMigration
{
    public function up(): void
    {
        // Acessa o IF caso a tabela ainda não exista
        if (!$this->hasTable('adms_daman_stages')) {

            // Definir as colunas da tabela
            $table = $this->table('adms_daman_stages');

            $table
                // Código identificador da etapa
                ->addColumn('code', 'string', [
                    'limit' => 50,
                    'null' => false,
                    'comment' => 'Código identificador da etapa'
                ])

                // Nome da etapa
                ->addColumn('name', 'string', [
                    'limit' => 150,
                    'null' => false,
                    'comment' => 'Nome da etapa, exemplo: Fundação, Estrutura, Alvenaria'
                ])

                // Status da etapa
                ->addColumn('status', 'tinyinteger', [
                    'limit' => 1,
                    'null' => false,
                    'default' => 1,
                    'comment' => 'Status da etapa: 1 - Ativo, 0 - Inativo'
                ])

                // Data de criação
                ->addColumn('created_at', 'timestamp', [
                    'null' => false
                ])

                // Data da última atualização
                ->addColumn('updated_at', 'timestamp', [
                    'null' => true
                ])

                // Impedir códigos duplicados
                ->addIndex(
                    ['code'],
                    [
                        'unique' => true,
                        'name' => 'idx_unique_adms_daman_stage_code'
                    ]
                )

                // Impedir nomes duplicados
                ->addIndex(
                    ['name'],
                    [
                        'unique' => true,
                        'name' => 'idx_unique_adms_daman_stage_name'
                    ]
                )

                ->create();
        }
    }


    /**
     * Método down() para reverter a migration.
     */
    public function down(): void
    {
        // Apagar a tabela caso exista
        if ($this->hasTable('adms_daman_stages')) {
            $this->table('adms_daman_stages')->drop()->save();
        }
    }
}
