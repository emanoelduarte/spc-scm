<?php

declare(strict_types=1);

use Phinx\Migration\AbstractMigration;

/**
 * Esta migration é responsável por criar a tabela adms_daman_order_item_allocations, que representa as apropriações orçamentárias dos itens do pedido de cada obra.
 */
final class AdmsDamanOrderItemAllocations extends AbstractMigration
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * https://book.cakephp.org/phinx/0/en/migrations.html#the-change-method
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function up(): void
{
    // Acessa o if se a tabela adms_daman_order_item_allocations não existir
    if (!$this->hasTable('adms_daman_order_item_allocations')) {

        // Definir as colunas da tabela
        $table = $this->table('adms_daman_order_item_allocations');

        $table->addColumn('order_item_id', 'integer', [
                'null' => false,
                'signed' => false,
                'comment' => 'ID do item do pedido vinculado à apropriação orçamentária'
            ])
            ->addForeignKey(
                'order_item_id',
                'adms_daman_order_items',
                'id',
                ['delete' => 'CASCADE', 'update' => 'CASCADE']
            )

            ->addColumn('budget_item_id', 'integer', [
                'null' => false,
                'signed' => false,
                'comment' => 'ID do item orçamentário ao qual o item do pedido foi apropriado'
            ])
            ->addForeignKey(
                'budget_item_id',
                'adms_daman_budget_items',
                'id',
                ['delete' => 'RESTRICT', 'update' => 'CASCADE']
            )

            ->addColumn('allocated_quantity', 'decimal', [
                'precision' => 15,
                'scale' => 4,
                'null' => true,
                'comment' => 'Quantidade do item apropriada para este item do orçamento'
            ])

            ->addColumn('allocated_value', 'decimal', [
                'precision' => 15,
                'scale' => 2,
                'null' => false,
                'default' => 0.00,
                'comment' => 'Valor financeiro apropriado para este item do orçamento'
            ])

            ->addColumn('status', 'enum', [
                'values' => [
                    'pending',
                    'approved',
                    'rejected',
                    'cancelled'
                ],
                'null' => false,
                'default' => 'pending',
                'comment' => 'Status da apropriação: pending, approved, rejected ou cancelled'
            ])

            ->addColumn('approved_by', 'integer', [
                'null' => true,
                'signed' => false,
                'comment' => 'ID do usuário responsável pela aprovação da apropriação'
            ])
            ->addForeignKey(
                'approved_by',
                'adms_daman_users',
                'id',
                ['delete' => 'SET_NULL', 'update' => 'CASCADE']
            )

            ->addColumn('approved_at', 'timestamp', [
                'null' => true,
                'comment' => 'Data e hora da aprovação da apropriação'
            ])

            ->addColumn('rejected_by', 'integer', [
                'null' => true,
                'signed' => false,
                'comment' => 'ID do usuário responsável pela rejeição da apropriação'
            ])
            ->addForeignKey(
                'rejected_by',
                'adms_daman_users',
                'id',
                ['delete' => 'SET_NULL', 'update' => 'CASCADE']
            )

            ->addColumn('rejected_at', 'timestamp', [
                'null' => true,
                'comment' => 'Data e hora da rejeição da apropriação'
            ])

            ->addColumn('rejection_reason', 'string', [
                'limit' => 500,
                'null' => true,
                'comment' => 'Motivo informado para a rejeição da apropriação'
            ])

            ->addColumn('created_at', 'timestamp', [
                'null' => false,
                'default' => 'CURRENT_TIMESTAMP',
                'comment' => 'Data e hora de criação do registro'
            ])

            ->addColumn('updated_at', 'timestamp', [
                'null' => true,
                'comment' => 'Data e hora da última atualização do registro'
            ])

            ->create();
    }
}

/**
 * Metodo down() para reverter a migração (caso necessário)
 */
public function down(): void
{
    // Apagar a tabela adms_daman_order_item_allocations
    if ($this->hasTable('adms_daman_order_item_allocations')) {
        $this->table('adms_daman_order_item_allocations')->drop()->save();
    }
}
}
