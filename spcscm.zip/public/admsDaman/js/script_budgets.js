document.addEventListener('DOMContentLoaded', function () {

    // =========================================================
    // ORÇAMENTOS - CADASTRO DE ORÇAMENTO E ETAPAS
    // =========================================================
    //
    // Este bloco controla:
    // - Adição dinâmica de etapas
    // - Remoção de etapas
    // - Atualização automática do sort_order
    // - Soma dos valores das etapas
    // - Cálculo do orçamento ainda não distribuído
    //
    // =========================================================


    // ---------------------------------------------------------
    // RECUPERAR ELEMENTOS DA VIEW
    // ---------------------------------------------------------

    // Container onde ficam todas as etapas cadastradas.
    // Cada etapa possui a classe ".stage-row".
    const stagesContainer = document.getElementById('stagesContainer');

    // Botão responsável por adicionar uma nova etapa ao formulário.
    const btnAddStage = document.getElementById('btnAddStage');

    // Input onde o usuário informa o valor total do orçamento da obra.
    const totalBudgetInput = document.getElementById('total_budget');

    // Elemento que contém as etapas enviadas pelo PHP
    const stagesDataEl = document.getElementById('stages-data');


    // ---------------------------------------------------------
    // ELEMENTOS DO RESUMO FINANCEIRO
    // ---------------------------------------------------------

    // Exibe o valor total informado para o orçamento.
    const summaryTotal = document.getElementById('summaryTotalBudget');

    // Exibe quanto do orçamento já foi distribuído entre as etapas.
    const summaryDistributed = document.getElementById('summaryDistributed');

    // Exibe quanto do orçamento ainda não foi distribuído.
    const summaryRemaining = document.getElementById('summaryRemaining');


    // ---------------------------------------------------------
    // VERIFICAR SE ESTAMOS NA PÁGINA DE CADASTRO DE ORÇAMENTO
    // ---------------------------------------------------------
    //
    // Como este código ficará dentro do script_admin.js,
    // esse arquivo será carregado também em outras páginas.
    //
    // Se os elementos abaixo não existirem, significa que
    // não estamos na página de cadastro de orçamento.
    //
    // Nesse caso o código é encerrado para evitar erros JS.
    //
    if (
        !stagesContainer ||
        !btnAddStage ||
        !totalBudgetInput ||
        !stagesDataEl
    ) {
        return;
    }

    // =========================================================
    // ETAPAS DISPONÍVEIS
    // =========================================================
    //
    // A View envia as etapas cadastradas no banco através
    // do atributo:
    //
    // data-stages="[...]"
    //
    // Aqui convertemos o JSON recebido para um array JavaScript.
    //
    const availableStages = JSON.parse(
        stagesDataEl.dataset.stages || '[]'
    );


    // Recuperar os dados antigos do formulário.
    //
    // Isso será útil caso a Controller devolva o formulário
    // após algum erro de validação.
    const oldStages = JSON.parse(
        stagesDataEl.dataset.oldStages || '[]'
    );

    // =========================================================
    // FUNÇÃO: CRIAR OPÇÕES DO SELECT DE ETAPAS
    // =========================================================
    //
    // Monta dinamicamente:
    //
    // <option value="">Selecione</option>
    // <option value="1">01 - Serviços Preliminares</option>
    // <option value="2">02 - Fundação</option>
    // ...
    //
    // selectedValue é utilizado caso alguma etapa precise
    // voltar selecionada após erro de validação.
    //
    function createStageOptions(selectedValue = null) {

        // Primeira opção
        let options =
            `<option value="">Selecione</option>`;


        // Percorrer todas as etapas recebidas do PHP
        availableStages.forEach(function (stage) {

            // Verificar se esta opção deve ficar selecionada
            const selected =
                stage.id == selectedValue
                    ? 'selected'
                    : '';


            // Criar a opção
            options += `
            <option
                value="${stage.id}"
                ${selected}>

                ${stage.code} - ${stage.name}

            </option>
        `;
        });


        return options;
    }


    // =========================================================
    // FUNÇÃO: CONVERTER VALOR MONETÁRIO PARA NÚMERO
    // =========================================================
    //
    // Recebe um valor no padrão brasileiro, por exemplo:
    //
    // "20.000,50"
    //
    // e transforma em:
    //
    // 20000.50
    //
    // Isso é necessário para conseguirmos realizar cálculos
    // matemáticos no JavaScript.
    //
    function parseMoney(value) {

        // Caso o valor esteja vazio, retorna zero.
        if (!value) {
            return 0;
        }

        // Remove elementos que não devem fazer parte
        // do número utilizado nos cálculos.
        value = value

            // Remove "R$"
            .replace('R$', '')

            // Remove espaços
            .replace(/\s/g, '')

            // Remove pontos usados como separadores de milhar
            .replace(/\./g, '')

            // Troca a vírgula decimal por ponto
            .replace(',', '.');


        // Converte a string para número decimal.
        const number = parseFloat(value);


        // Caso o resultado não seja um número válido,
        // retorna zero.
        return isNaN(number) ? 0 : number;
    }


    // =========================================================
    // FUNÇÃO: FORMATAR VALOR COMO REAL
    // =========================================================
    //
    // Recebe:
    //
    // 20000
    //
    // Retorna:
    //
    // R$ 20.000,00
    //
    function formatMoney(value) {

        return new Intl.NumberFormat(
            'pt-BR',
            {
                // Informar que queremos formato monetário
                style: 'currency',

                // Informar a moeda utilizada
                currency: 'BRL'
            }
        ).format(value);
    }


    // =========================================================
    // FUNÇÃO: ATUALIZAR ÍNDICES DAS ETAPAS
    // =========================================================
    //
    // Essa função é muito importante.
    //
    // O formulário envia as etapas assim:
    //
    // stages[0][code]
    // stages[0][name]
    // stages[0][budget_value]
    //
    // stages[1][code]
    // stages[1][name]
    // stages[1][budget_value]
    //
    // Caso uma etapa seja removida, precisamos reorganizar
    // esses índices.
    //
    // Exemplo:
    //
    // Antes:
    // Etapa 1 -> índice 0
    // Etapa 2 -> índice 1
    // Etapa 3 -> índice 2
    //
    // Se Etapa 2 for removida:
    //
    // Etapa 1 -> índice 0
    // Etapa 3 -> índice 1
    //
    // =========================================================
    // FUNÇÃO: ATUALIZAR ÍNDICES DAS ETAPAS
    // =========================================================
    //
    // Mantém os índices organizados após adicionar
    // ou remover etapas.
    //
    // Exemplo:
    //
    // stages[0][adms_daman_stage_id]
    // stages[0][budget_value]
    // stages[0][sort_order]
    //
    // stages[1][adms_daman_stage_id]
    // stages[1][budget_value]
    // stages[1][sort_order]
    //
    function updateStageIndexes() {

        // Recuperar todas as etapas
        const stages =
            stagesContainer.querySelectorAll(
                '.stage-row'
            );


        // Percorrer as etapas
        stages.forEach(function (stage, index) {

            // Atualizar índice interno
            stage.dataset.index = index;


            // Recuperar os elementos
            const title =
                stage.querySelector('.stage-title');

            const stageSelect =
                stage.querySelector('.stage-select');

            const budgetValue =
                stage.querySelector(
                    '.stage-budget-value'
                );

            const sortOrder =
                stage.querySelector(
                    '.stage-sort-order'
                );


            // Atualizar título visual
            if (title) {

                title.textContent =
                    'Etapa ' + (index + 1);
            }


            // Atualizar name do select
            if (stageSelect) {

                stageSelect.name =
                    `stages[${index}][adms_daman_stage_id]`;
            }


            // Atualizar name do valor
            if (budgetValue) {

                budgetValue.name =
                    `stages[${index}][budget_value]`;
            }


            // Atualizar sort_order
            if (sortOrder) {

                sortOrder.name =
                    `stages[${index}][sort_order]`;

                sortOrder.value =
                    index + 1;
            }
        });


        // Atualizar botões de remoção
        updateRemoveButtons();
    }


    // =========================================================
    // FUNÇÃO: CONTROLAR BOTÃO REMOVER
    // =========================================================
    //
    // Não queremos permitir que o usuário remova todas as etapas.
    //
    // Portanto, quando existir apenas uma etapa,
    // o botão "Remover" fica desabilitado.
    //
    function updateRemoveButtons() {

        // Recuperar todas as etapas.
        const stages = stagesContainer.querySelectorAll('.stage-row');


        // Percorrer as etapas.
        stages.forEach(function (stage) {

            // Recuperar o botão remover daquela etapa.
            const button = stage.querySelector('.btn-remove-stage');


            // Segurança para garantir que o botão existe.
            if (button) {

                // Se existir somente uma etapa,
                // desabilitar o botão.
                button.disabled = stages.length === 1;
            }
        });
    }


    // =========================================================
    // FUNÇÃO: ATUALIZAR RESUMO DO ORÇAMENTO
    // =========================================================
    //
    // Calcula:
    //
    // Orçamento Total
    // -
    // Soma das Etapas
    // =
    // Não Distribuído
    //
    function updateSummary() {

        // Converter o valor total digitado pelo usuário
        // para um número utilizável em cálculos.
        const totalBudget = parseMoney(totalBudgetInput.value);


        // Variável que armazenará a soma das etapas.
        let distributed = 0;


        // -----------------------------------------------------
        // SOMAR VALORES DAS ETAPAS
        // -----------------------------------------------------

        // Recuperar todos os campos de valor das etapas.
        stagesContainer
            .querySelectorAll('.stage-budget-value')
            .forEach(function (input) {

                // Converter o valor da etapa para número
                // e adicionar ao total distribuído.
                distributed += parseMoney(input.value);
            });


        // -----------------------------------------------------
        // CALCULAR VALOR NÃO DISTRIBUÍDO
        // -----------------------------------------------------

        const remaining = totalBudget - distributed;


        // -----------------------------------------------------
        // ATUALIZAR VALORES NA TELA
        // -----------------------------------------------------

        // Exibir orçamento total formatado.
        if (summaryTotal) {

            summaryTotal.textContent =
                formatMoney(totalBudget);
        }


        // Exibir valor distribuído.
        if (summaryDistributed) {

            summaryDistributed.textContent =
                formatMoney(distributed);
        }


        // Exibir saldo ainda não distribuído.
        if (summaryRemaining) {

            summaryRemaining.textContent =
                formatMoney(remaining);


            // Remover possíveis classes anteriores.
            summaryRemaining.classList.remove(
                'text-success',
                'text-danger'
            );


            // -------------------------------------------------
            // DEFINIR COR DO SALDO
            // -------------------------------------------------

            // Caso tenha ultrapassado o orçamento,
            // mostrar em vermelho.
            if (remaining < 0) {

                summaryRemaining.classList.add(
                    'text-danger'
                );

            } else {

                // Caso ainda exista saldo,
                // mostrar em verde.
                summaryRemaining.classList.add(
                    'text-success'
                );
            }
        }
    }


    // =========================================================
    // EVENTO: ADICIONAR NOVA ETAPA
    // =========================================================
    //
    // Cria uma nova linha contendo:
    //
    // - Select da etapa
    // - Valor orçado
    // - sort_order oculto
    // - Botão remover
    //
    btnAddStage.addEventListener('click', function () {

        // Quantidade atual de etapas.
        //
        // Será utilizada como índice da nova etapa.
        const index =
            stagesContainer
                .querySelectorAll('.stage-row')
                .length;


        // Caso existam dados antigos para este índice,
        // recuperar qual etapa estava selecionada.
        const selectedStage =
            oldStages[index]?.adms_daman_stage_id
            ?? '';


        // =====================================================
        // CRIAR A NOVA ETAPA
        // =====================================================

        const stageHTML = `

        <div
            class="stage-row border rounded p-3 mb-3"
            data-index="${index}">


            <!-- Cabeçalho -->
            <div class="d-flex align-items-center mb-3">

                <strong class="stage-title">

                    Etapa ${index + 1}

                </strong>


                <button
                    type="button"
                    class="btn btn-danger btn-sm
                           ms-auto btn-remove-stage">

                    <i class="fa-solid fa-trash"></i>

                    Remover

                </button>

            </div>


            <div class="row g-3">


                <!-- ======================================= -->
                <!-- ETAPA                                   -->
                <!-- ======================================= -->

                <div class="col-md-8">

                    <label class="form-label">

                        Etapa:

                    </label>


                    <select
                        name="stages[${index}][adms_daman_stage_id]"
                        class="form-select stage-select">

                        ${createStageOptions(selectedStage)}

                    </select>

                </div>


                <!-- ======================================= -->
                <!-- VALOR ORÇADO                            -->
                <!-- ======================================= -->

                <div class="col-md-4">

                    <label class="form-label">

                        Valor Orçado:

                    </label>


                    <div class="input-group">

                        <span class="input-group-text">

                            R$

                        </span>


                        <input
                            type="text"
                            class="form-control
                                   stage-budget-value"
                            name="stages[${index}][budget_value]"
                            inputmode="decimal"
                            placeholder="0,00">

                    </div>

                </div>


                <!-- ======================================= -->
                <!-- ORDEM DA ETAPA                          -->
                <!-- ======================================= -->

                <input
                    type="hidden"
                    class="stage-sort-order"
                    name="stages[${index}][sort_order]"
                    value="${index + 1}">


            </div>

        </div>
    `;


        // Inserir a nova etapa no formulário
        stagesContainer.insertAdjacentHTML(
            'beforeend',
            stageHTML
        );


        // Reorganizar os índices
        updateStageIndexes();


        // Atualizar o resumo financeiro
        updateSummary();
    });


    // =========================================================
    // EVENTO: REMOVER ETAPA
    // =========================================================
    //
    // Estamos usando delegação de evento porque os botões
    // de remover podem ser criados dinamicamente.
    //
    // Em vez de adicionar um evento individual para cada botão,
    // adicionamos um único evento no stagesContainer.
    //
    stagesContainer.addEventListener('click', function (event) {

        // Verificar se o usuário clicou no botão Remover
        // ou em algum elemento dentro dele, como o ícone.
        const removeButton =
            event.target.closest('.btn-remove-stage');


        // Caso o clique não tenha ocorrido em um botão remover,
        // não fazemos nada.
        if (!removeButton) {
            return;
        }


        // Recuperar todas as etapas atuais.
        const stages =
            stagesContainer.querySelectorAll('.stage-row');


        // Não permitir remover a última etapa.
        if (stages.length <= 1) {
            return;
        }


        // Localizar a etapa correspondente ao botão
        // e removê-la do HTML.
        removeButton
            .closest('.stage-row')
            .remove();


        // Após remover, reorganizar os índices.
        updateStageIndexes();


        // Recalcular os valores.
        updateSummary();
    });


    // =========================================================
    // EVENTO: ALTERAÇÃO DO ORÇAMENTO TOTAL
    // =========================================================
    //
    // Sempre que o usuário digitar no campo
    // "Orçamento Total", recalcular o resumo.
    //
    totalBudgetInput.addEventListener(
        'input',
        updateSummary
    );


    // =========================================================
    // EVENTO: ALTERAÇÃO DO VALOR DE UMA ETAPA
    // =========================================================
    //
    // Esse evento também usa delegação.
    //
    // Sempre que algum campo dentro do stagesContainer
    // for alterado, verificamos se ele é um campo
    // ".stage-budget-value".
    //
    stagesContainer.addEventListener('input', function (event) {

        // Verificar se o campo alterado
        // é o valor de uma etapa.
        if (
            event.target.classList.contains(
                'stage-budget-value'
            )
        ) {

            // Atualizar o resumo financeiro.
            updateSummary();
        }
    });


    // =========================================================
    // INICIALIZAÇÃO
    // =========================================================
    //
    // Essas funções são chamadas ao abrir a página para:
    //
    // 1. Corrigir os índices das etapas já existentes
    // 2. Definir corretamente o botão remover
    // 3. Calcular os valores iniciais do orçamento
    //
    // Isso também é útil quando o formulário volta preenchido
    // após algum erro de validação no backend.
    //
    updateStageIndexes();
    updateSummary();

});