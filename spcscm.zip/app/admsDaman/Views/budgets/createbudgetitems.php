<?php

use App\admsDaman\Helpers\CSRFHelper;

// Dados da etapa do orçamento
$budgetStage = $this->data['budgetStage'] ?? [];

// Dados que retornaram do formulário após eventual erro
$form = $this->data['form'] ?? [];


// ID da etapa específica do orçamento
$budgetStageId = (int) (
    $budgetStage['budget_stage_id'] ?? 0
);


// Valor definido para a etapa
$stageBudgetValue = (float) (
    $budgetStage['stage_budget_value'] ?? 0
);


// Total dos itens já cadastrados
$itemsTotal = (float) (
    $budgetStage['items_total'] ?? 0
);


// Valor ainda disponível na etapa
$availableValue = (float) (
    $budgetStage['available_value']
    ?? ($stageBudgetValue - $itemsTotal)
);

?>

<div class="container-fluid px-4">


    <!-- ====================================================== -->
    <!-- TÍTULO E BREADCRUMB                                    -->
    <!-- ====================================================== -->

    <div class="mb-1 hstack gap-2">

        <h2 class="mt-3">
            Itens do Orçamento
        </h2>


        <ol class="breadcrumb mb-3 mt-3 ms-auto">

            <li class="breadcrumb-item">

                <a
                    class="text-decoration-none"
                    href="<?= $_ENV['URL_ADM']; ?>dashboard">

                    Dashboard

                </a>

            </li>


            <li class="breadcrumb-item">

                <a
                    class="text-decoration-none"
                    href="<?= $_ENV['URL_ADM']; ?>list-budgets">

                    Orçamentos

                </a>

            </li>


            <li
                class="breadcrumb-item active"
                aria-current="page">

                Cadastrar Item

            </li>

        </ol>

    </div>


    <!-- ====================================================== -->
    <!-- CARD PRINCIPAL                                         -->
    <!-- ====================================================== -->

    <div class="card mb-4 border-light shadow">


        <!-- Cabeçalho -->
        <div class="card-header hstack gap-2">

            <span>

                <i class="fa-solid fa-box-open me-1"></i>

                Cadastrar Item

            </span>


            <span class="ms-auto d-sm-flex flex-row">

                <?php if (
                    in_array(
                        "ListBudgets",
                        $this->data['buttonPermissions'] ?? []
                    )
                ): ?>

                    <a
                        href="<?= $_ENV['URL_ADM']; ?>list-budgets"
                        class="btn btn-info btn-sm me-1 mb-1">

                        <i class="fa-solid fa-list"></i>

                        Orçamentos

                    </a>

                <?php endif; ?>

            </span>

        </div>


        <div class="card-body">


            <?php

            // Incluir arquivo responsável pelos alertas
            include './app/admsDaman/Views/partials/alerts.php';

            ?>


            <!-- ================================================== -->
            <!-- CONTEXTO DO ORÇAMENTO                               -->
            <!-- ================================================== -->

            <div class="mb-4">

                <h5 class="border-bottom pb-2 mb-3">

                    <i class="fa-solid fa-building me-1"></i>

                    Dados da Etapa

                </h5>


                <div class="row g-3">


                    <!-- Obra -->
                    <div class="col-lg-6 col-md-12">

                        <div class="border rounded p-3 h-100">

                            <span class="text-muted small">
                                Obra
                            </span>


                            <div class="fw-semibold">

                                <?= htmlspecialchars(
                                    $budgetStage['project_name'] ?? '-'
                                ); ?>

                            </div>

                        </div>

                    </div>


                    <!-- Etapa -->
                    <div class="col-lg-6 col-md-12">

                        <div class="border rounded p-3 h-100">

                            <span class="text-muted small">
                                Etapa
                            </span>


                            <div class="fw-semibold">

                                <?php if (
                                    !empty($budgetStage['stage_code'])
                                ): ?>

                                    <span class="badge bg-secondary me-1">

                                        <?= htmlspecialchars(
                                            $budgetStage['stage_code']
                                        ); ?>

                                    </span>

                                <?php endif; ?>


                                <?= htmlspecialchars(
                                    $budgetStage['stage_name'] ?? '-'
                                ); ?>

                            </div>

                        </div>

                    </div>

                </div>


                <!-- Resumo financeiro -->
                <div class="row g-3 mt-1">


                    <!-- Valor da etapa -->
                    <div class="col-lg-4 col-md-6">

                        <div class="card border-primary h-100">

                            <div class="card-body">

                                <span
                                    class="small text-muted text-uppercase">

                                    Valor da Etapa

                                </span>


                                <div class="fs-5 fw-bold">

                                    R$

                                    <?= number_format(
                                        $stageBudgetValue,
                                        2,
                                        ',',
                                        '.'
                                    ); ?>

                                </div>

                            </div>

                        </div>

                    </div>


                    <!-- Total cadastrado -->
                    <div class="col-lg-4 col-md-6">

                        <div class="card border-secondary h-100">

                            <div class="card-body">

                                <span
                                    class="small text-muted text-uppercase">

                                    Total dos Itens

                                </span>


                                <div class="fs-5 fw-bold">

                                    R$

                                    <?= number_format(
                                        $itemsTotal,
                                        2,
                                        ',',
                                        '.'
                                    ); ?>

                                </div>

                            </div>

                        </div>

                    </div>


                    <!-- Saldo disponível -->
                    <div class="col-lg-4 col-md-6">

                        <div
                            class="card <?= $availableValue >= 0
                                ? 'border-success'
                                : 'border-danger'; ?> h-100">

                            <div class="card-body">

                                <span
                                    class="small text-muted text-uppercase">

                                    Disponível

                                </span>


                                <div
                                    class="fs-5 fw-bold <?= $availableValue >= 0
                                        ? 'text-success'
                                        : 'text-danger'; ?>">

                                    R$

                                    <?= number_format(
                                        $availableValue,
                                        2,
                                        ',',
                                        '.'
                                    ); ?>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>


            <!-- ================================================== -->
            <!-- FORMULÁRIO                                          -->
            <!-- ================================================== -->

            <form
                action=""
                method="POST"
                class="row g-3">


                <!-- CSRF -->
                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= CSRFHelper::generateCSRFToken(
                        'form_create_budget_item'
                    ); ?>">


                <!-- ID da etapa do orçamento -->
                <input
                    type="hidden"
                    name="budget_stage_id"
                    value="<?= $budgetStageId; ?>">


                <!-- ================================================== -->
                <!-- DADOS DO ITEM                                      -->
                <!-- ================================================== -->

                <div class="col-12">

                    <h5 class="border-bottom pb-2">

                        <i class="fa-solid fa-box me-1"></i>

                        Dados do Item

                    </h5>

                </div>


                <!-- Código -->
                <div class="col-lg-2 col-md-4 col-sm-12">

                    <label
                        for="code"
                        class="form-label">

                        Código:

                    </label>


                    <input
                        type="text"
                        class="form-control"
                        id="code"
                        name="code"
                        value="<?= htmlspecialchars(
                            $form['code'] ?? ''
                        ); ?>"
                        placeholder="Ex: 01.01">

                </div>


                <!-- Descrição -->
                <div class="col-lg-10 col-md-8 col-sm-12">

                    <label
                        for="description"
                        class="form-label">

                        Descrição:

                    </label>


                    <input
                        type="text"
                        class="form-control"
                        id="description"
                        name="description"
                        value="<?= htmlspecialchars(
                            $form['description'] ?? ''
                        ); ?>"
                        placeholder="Ex: Cimento CP II 50kg">

                </div>


                <!-- Unidade -->
                <div class="col-lg-3 col-md-6 col-sm-12">

                    <label
                        for="adms_daman_measurement_units_id"
                        class="form-label">

                        Unidade:

                    </label>


                    <select
                        name="adms_daman_measurement_units_id"
                        class="form-select"
                        id="adms_daman_measurement_units_id">

                        <option value="">
                            Selecione
                        </option>


                        <?php

                        // Verificar se existem unidades cadastradas
                        if (
                            $this->data[
                                'getAllMeasurementUnitsSelect'
                            ] ?? false
                        ) {

                            // Percorrer unidades de medida
                            foreach (
                                $this->data[
                                    'getAllMeasurementUnitsSelect'
                                ] as $measurementUnit
                            ) {

                                // Unidade anteriormente selecionada
                                $selected =
                                    isset(
                                        $form[
                                            'adms_daman_measurement_units_id'
                                        ]
                                    )
                                    && $form[
                                        'adms_daman_measurement_units_id'
                                    ] == $measurementUnit['id']
                                        ? 'selected'
                                        : '';

                                ?>

                                <option
                                    value="<?= (int) $measurementUnit['id']; ?>"
                                    <?= $selected; ?>>

                                    <?= htmlspecialchars(
                                        $measurementUnit['name']
                                    ); ?>

                                </option>

                                <?php
                            }
                        }

                        ?>

                    </select>

                </div>


                <!-- Quantidade -->
                <div class="col-lg-3 col-md-6 col-sm-12">

                    <label
                        for="quantity"
                        class="form-label">

                        Quantidade:

                    </label>


                    <input
                        type="text"
                        class="form-control"
                        id="quantity"
                        name="quantity"
                        inputmode="decimal"
                        value="<?= htmlspecialchars(
                            $form['quantity'] ?? ''
                        ); ?>"
                        placeholder="0,00">

                </div>


                <!-- Preço Unitário -->
                <div class="col-lg-3 col-md-6 col-sm-12">

                    <label
                        for="unit_price"
                        class="form-label">

                        Preço Unitário:

                    </label>


                    <div class="input-group">

                        <span class="input-group-text">
                            R$
                        </span>


                        <input
                            type="text"
                            class="form-control"
                            id="unit_price"
                            name="unit_price"
                            inputmode="decimal"
                            value="<?= htmlspecialchars(
                                $form['unit_price'] ?? ''
                            ); ?>"
                            placeholder="0,00">

                    </div>

                </div>


                <!-- Valor Orçado -->
                <div class="col-lg-3 col-md-6 col-sm-12">

                    <label
                        for="budget_value"
                        class="form-label">

                        Valor Orçado:

                    </label>


                    <div class="input-group">

                        <span class="input-group-text">
                            R$
                        </span>


                        <input
                            type="text"
                            class="form-control"
                            id="budget_value"
                            name="budget_value"
                            inputmode="decimal"
                            value="<?= htmlspecialchars(
                                $form['budget_value'] ?? ''
                            ); ?>"
                            placeholder="0,00">

                    </div>

                </div>


                <!-- ================================================== -->
                <!-- INFORMAÇÃO                                         -->
                <!-- ================================================== -->

                <div class="col-12">

                    <div
                        class="alert alert-info py-2 mb-0"
                        role="alert">

                        <i class="fa-solid fa-circle-info me-1"></i>

                        O valor deste item será considerado na
                        composição financeira da etapa

                        <strong>

                            <?= htmlspecialchars(
                                $budgetStage['stage_name'] ?? ''
                            ); ?>.

                        </strong>

                    </div>

                </div>


                <!-- ================================================== -->
                <!-- BOTÕES                                             -->
                <!-- ================================================== -->

                <div class="col-12">

                    <button
                        type="submit"
                        name="AddBudgetItem"
                        value="Cadastrar"
                        class="btn btn-primary btn-sm">

                        <i class="fa-solid fa-floppy-disk"></i>

                        Cadastrar Item

                    </button>


                    <a
                        href="<?= $_ENV['URL_ADM']; ?>list-budgets"
                        class="btn btn-secondary btn-sm">

                        <i class="fa-solid fa-arrow-left"></i>

                        Voltar

                    </a>

                </div>

            </form>

        </div>

    </div>

</div>