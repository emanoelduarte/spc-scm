<?php

$budgets = $this->data['budgets'] ?? [];

?>

<div class="container-fluid px-4">

    <!-- ====================================================== -->
    <!-- TÍTULO E BREADCRUMB                                    -->
    <!-- ====================================================== -->

    <div class="mb-1 d-flex flex-column flex-sm-row gap-2">

        <h2 class="mt-3">Orçamentos</h2>

        <ol class="breadcrumb mb-3 mt-0 mt-sm-3 ms-auto">

            <li class="breadcrumb-item">

                <a
                    class="text-decoration-none"
                    href="<?= $_ENV['URL_ADM']; ?>dashboard">

                    Dashboard

                </a>

            </li>

            <li
                class="breadcrumb-item active"
                aria-current="page">

                Orçamentos

            </li>

        </ol>

    </div>


    <?php

    // Incluir arquivo responsável pelos alertas
    include './app/admsDaman/Views/partials/alerts.php';

    ?>


    <!-- ====================================================== -->
    <!-- CARD DE AÇÕES DA PÁGINA                                -->
    <!-- ====================================================== -->

    <div class="card mb-4 border-light shadow">

        <div class="card-header hstack gap-2">

            <span>

                <i class="fa-solid fa-file-invoice-dollar me-1"></i>

                Gerenciar Orçamentos

            </span>


            <span class="ms-auto d-flex flex-row gap-1">

                <!--
                    Botão reservado para os filtros.
                    A funcionalidade será implementada posteriormente.
                -->
                <button
                    type="button"
                    class="btn btn-secondary btn-sm">

                    <i class="fa-solid fa-filter"></i>

                    Filtros

                </button>


                <?php if (
                    in_array(
                        "CreateBudget",
                        $this->data['buttonPermissions'] ?? []
                    )
                ): ?>

                    <a
                        href="<?= $_ENV['URL_ADM']; ?>create-budget"
                        class="btn btn-success btn-sm">

                        <i class="fa-solid fa-circle-plus"></i>

                        Cadastrar Orçamento

                    </a>

                <?php endif; ?>

            </span>

        </div>

    </div>


    <!-- ====================================================== -->
    <!-- LISTAGEM DOS ORÇAMENTOS                                -->
    <!-- ====================================================== -->

    <?php if (!empty($budgets)): ?>


        <?php foreach ($budgets as $budget): ?>


            <?php

            // --------------------------------------------------
            // VALOR TOTAL DO ORÇAMENTO
            // --------------------------------------------------

            $totalBudget = (float) (
                $budget['total_budget'] ?? 0
            );


            // --------------------------------------------------
            // SOMAR OS VALORES DISTRIBUÍDOS ENTRE AS ETAPAS
            // --------------------------------------------------

            $distributedBudget = 0;

            foreach ($budget['stages'] ?? [] as $stage) {

                $distributedBudget += (float) (
                    $stage['budget_value'] ?? 0
                );
            }


            // --------------------------------------------------
            // VALOR AINDA NÃO DISTRIBUÍDO
            // --------------------------------------------------

            $remainingBudget =
                $totalBudget - $distributedBudget;


            // --------------------------------------------------
            // PERCENTUAL DISTRIBUÍDO
            // --------------------------------------------------

            $distributedPercent = $totalBudget > 0
                ? ($distributedBudget / $totalBudget) * 100
                : 0;


            // --------------------------------------------------
            // LIMITAR A BARRA VISUAL ENTRE 0% E 100%
            // --------------------------------------------------

            $progressPercent = max(
                0,
                min(100, $distributedPercent)
            );

            ?>


            <!-- ================================================== -->
            <!-- CARD MESTRE DO ORÇAMENTO                           -->
            <!-- ================================================== -->

            <div class="card mb-4 border-light shadow">


                <!-- ============================================== -->
                <!-- CABEÇALHO DO ORÇAMENTO                         -->
                <!-- ============================================== -->

                <div class="card-header hstack gap-2 py-3">

                    <div>

                        <div class="fw-semibold">

                            <i class="fa-solid fa-building me-1"></i>

                            <?= htmlspecialchars(
                                $budget['project_name'] ?? 'Obra'
                            ); ?>

                        </div>


                        <small class="text-muted">

                            Orçamento #<?= (int) $budget['id']; ?>

                        </small>

                    </div>


                    <!-- Status -->
                    <div class="ms-auto">

                        <?php if (
                            ($budget['type'] ?? '') === 'approved'
                        ): ?>

                            <span class="badge bg-success">

                                Aprovado

                            </span>


                        <?php elseif (
                            ($budget['type'] ?? '') === 'draft'
                        ): ?>

                            <span class="badge bg-warning text-dark">

                                Rascunho

                            </span>


                        <?php else: ?>

                            <span class="badge bg-secondary">

                                Inativo

                            </span>

                        <?php endif; ?>

                    </div>

                </div>


                <!-- ============================================== -->
                <!-- CORPO DO CARD MESTRE                           -->
                <!-- ============================================== -->

                <div class="card-body">


                    <!-- ========================================== -->
                    <!-- CARDS DE RESUMO FINANCEIRO                 -->
                    <!-- ========================================== -->

                    <div class="row">


                        <!-- Orçamento total -->
                        <div class="col-xl-4 col-md-6 mb-3">

                            <div class="card border-primary h-100">

                                <div class="card-body">

                                    <div class="d-flex align-items-center">

                                        <div>

                                            <div
                                                class="small text-muted text-uppercase">

                                                Orçamento Total

                                            </div>


                                            <div class="fs-4 fw-bold">

                                                R$

                                                <?= number_format(
                                                    $totalBudget,
                                                    2,
                                                    ',',
                                                    '.'
                                                ); ?>

                                            </div>

                                        </div>


                                        <div class="ms-auto">

                                            <i
                                                class="fa-solid fa-sack-dollar fa-2x text-muted">
                                            </i>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>


                        <!-- Orçamento distribuído -->
                        <div class="col-xl-4 col-md-6 mb-3">

                            <div class="card border-success h-100">

                                <div class="card-body">

                                    <div class="d-flex align-items-center">

                                        <div>

                                            <div
                                                class="small text-muted text-uppercase">

                                                Distribuído

                                            </div>


                                            <div class="fs-4 fw-bold">

                                                R$

                                                <?= number_format(
                                                    $distributedBudget,
                                                    2,
                                                    ',',
                                                    '.'
                                                ); ?>

                                            </div>

                                        </div>


                                        <div class="ms-auto">

                                            <i
                                                class="fa-solid fa-layer-group fa-2x text-muted">
                                            </i>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>


                        <!-- Orçamento não distribuído -->
                        <div class="col-xl-4 col-md-6 mb-3">

                            <div class="card border-warning h-100">

                                <div class="card-body">

                                    <div class="d-flex align-items-center">

                                        <div>

                                            <div
                                                class="small text-muted text-uppercase">

                                                Não Distribuído

                                            </div>


                                            <div
                                                class="fs-4 fw-bold
                                                <?= $remainingBudget < 0
                                                    ? 'text-danger'
                                                    : ''; ?>">

                                                R$

                                                <?= number_format(
                                                    $remainingBudget,
                                                    2,
                                                    ',',
                                                    '.'
                                                ); ?>

                                            </div>

                                        </div>


                                        <div class="ms-auto">

                                            <i
                                                class="fa-solid fa-wallet fa-2x text-muted">
                                            </i>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>


                    <!-- ========================================== -->
                    <!-- DISTRIBUIÇÃO DO ORÇAMENTO                  -->
                    <!-- ========================================== -->

                    <div class="mt-2">

                        <div
                            class="d-flex justify-content-between mb-1">

                            <span class="small fw-bold">

                                Distribuição entre as etapas

                            </span>


                            <span class="small">

                                <?= number_format(
                                    $distributedPercent,
                                    1,
                                    ',',
                                    '.'
                                ); ?>%

                            </span>

                        </div>


                        <div
                            class="progress"
                            style="height: 18px;">

                            <div
                                class="progress-bar"
                                role="progressbar"
                                style="width: <?= $progressPercent; ?>%;"
                                aria-valuenow="<?= $progressPercent; ?>"
                                aria-valuemin="0"
                                aria-valuemax="100">

                                <?= number_format(
                                    $distributedPercent,
                                    1,
                                    ',',
                                    '.'
                                ); ?>%

                            </div>

                        </div>

                    </div>


                    <!-- ========================================== -->
                    <!-- INFORMAÇÕES DE CONTROLE                    -->
                    <!-- ========================================== -->

                    <div class="row mt-4">


                        <!-- Criado por -->
                        <div class="col-md-4 mb-2">

                            <span class="text-muted small">

                                Criado por

                            </span>


                            <div class="fw-semibold">

                                <?= htmlspecialchars(
                                    $budget['created_by_name'] ?? '-'
                                ); ?>

                            </div>

                        </div>


                        <!-- Aprovado por -->
                        <div class="col-md-4 mb-2">

                            <span class="text-muted small">

                                Aprovado por

                            </span>


                            <div class="fw-semibold">

                                <?= htmlspecialchars(
                                    $budget['approved_by_name']
                                        ?? 'Não aprovado'
                                ); ?>

                            </div>

                        </div>


                        <!-- Criado em -->
                        <div class="col-md-4 mb-2">

                            <span class="text-muted small">

                                Criado em

                            </span>


                            <div class="fw-semibold">

                                <?php if (
                                    !empty($budget['created_at'])
                                ): ?>

                                    <?= date(
                                        'd/m/Y H:i',
                                        strtotime(
                                            $budget['created_at']
                                        )
                                    ); ?>

                                <?php else: ?>

                                    -

                                <?php endif; ?>

                            </div>

                        </div>

                    </div>


                    <!-- ========================================== -->
                    <!-- DIVISÃO ENTRE RESUMO E ETAPAS              -->
                    <!-- ========================================== -->

                    <hr class="my-4">


                    <!-- ========================================== -->
                    <!-- CARD INTERNO DAS ETAPAS                    -->
                    <!-- ========================================== -->

                    <div class="card border">

                        <div class="card-header hstack gap-2">

                            <span>

                                <i
                                    class="fa-solid fa-list-check me-1">
                                </i>

                                Etapas do Orçamento

                            </span>


                            <span class="ms-auto">

                                <span class="badge bg-secondary">

                                    <?= count(
                                        $budget['stages'] ?? []
                                    ); ?>


                                    <?= count(
                                        $budget['stages'] ?? []
                                    ) === 1
                                        ? 'Etapa'
                                        : 'Etapas'; ?>

                                </span>

                            </span>

                        </div>


                        <div class="card-body">


                            <?php if (
                                !empty($budget['stages'])
                            ): ?>


                                <!-- ============================== -->
                                <!-- ACCORDION DAS ETAPAS            -->
                                <!-- ============================== -->

                                <div
                                    class="accordion"
                                    id="budgetAccordion<?= (int) $budget['id']; ?>">


                                    <?php foreach (
                                        $budget['stages'] as $stage
                                    ): ?>


                                        <?php

                                        // --------------------------
                                        // Valor total da etapa
                                        // --------------------------

                                        $stageValue = (float) (
                                            $stage['budget_value']
                                            ?? 0
                                        );


                                        // --------------------------
                                        // Somar itens da etapa
                                        // --------------------------

                                        $itemsTotal = 0;

                                        foreach (
                                            $stage['items'] ?? []
                                            as $item
                                        ) {

                                            $itemsTotal += (float) (
                                                $item['budget_value']
                                                ?? 0
                                            );
                                        }


                                        // --------------------------
                                        // Diferença da etapa
                                        // --------------------------

                                        $stageDifference =
                                            $stageValue
                                            - $itemsTotal;


                                        // --------------------------
                                        // Percentual da composição
                                        // --------------------------

                                        $stagePercent =
                                            $stageValue > 0
                                            ? (
                                                $itemsTotal
                                                / $stageValue
                                            ) * 100
                                            : 0;


                                        // --------------------------
                                        // Limitar progress visual
                                        // --------------------------

                                        $stageProgress = max(
                                            0,
                                            min(
                                                100,
                                                $stagePercent
                                            )
                                        );

                                        ?>


                                        <!-- ====================== -->
                                        <!-- ETAPA                    -->
                                        <!-- ====================== -->

                                        <div class="accordion-item">


                                            <!-- Cabeçalho -->
                                            <h2
                                                class="accordion-header"
                                                id="headingStage<?= (int) $stage['budget_stage_id']; ?>">


                                                <button
                                                    class="accordion-button collapsed"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapseStage<?= (int) $stage['budget_stage_id']; ?>"
                                                    aria-expanded="false">


                                                    <div
                                                        class="d-flex flex-column flex-md-row
                                                               align-items-md-center
                                                               justify-content-between
                                                               w-100 me-3 gap-2">


                                                        <!-- Nome -->
                                                        <div>

                                                            <span
                                                                class="badge bg-secondary me-2">

                                                                <?= htmlspecialchars(
                                                                    $stage['code']
                                                                        ?? ''
                                                                ); ?>

                                                            </span>


                                                            <strong>

                                                                <?= htmlspecialchars(
                                                                    $stage['name']
                                                                        ?? ''
                                                                ); ?>

                                                            </strong>

                                                        </div>


                                                        <!-- Valor -->
                                                        <div class="fw-bold">

                                                            R$

                                                            <?= number_format(
                                                                $stageValue,
                                                                2,
                                                                ',',
                                                                '.'
                                                            ); ?>

                                                        </div>

                                                    </div>

                                                </button>

                                            </h2>


                                            <!-- ================== -->
                                            <!-- CONTEÚDO DA ETAPA   -->
                                            <!-- ================== -->

                                            <div
                                                id="collapseStage<?= (int) $stage['budget_stage_id']; ?>"
                                                class="accordion-collapse collapse"
                                                data-bs-parent="#budgetAccordion<?= (int) $budget['id']; ?>">


                                                <div class="accordion-body">


                                                    <!-- ================== -->
                                                    <!-- RESUMO DA ETAPA     -->
                                                    <!-- ================== -->

                                                    <div class="row mb-3">


                                                        <!-- Valor etapa -->
                                                        <div
                                                            class="col-lg-4 col-md-6 mb-2">

                                                            <div
                                                                class="border rounded p-3 h-100">

                                                                <span
                                                                    class="text-muted small">

                                                                    Valor da Etapa

                                                                </span>


                                                                <div
                                                                    class="fw-bold fs-5">

                                                                    R$

                                                                    <?= number_format(
                                                                        $stageValue,
                                                                        2,
                                                                        ',',
                                                                        '.'
                                                                    ); ?>

                                                                </div>

                                                            </div>

                                                        </div>


                                                        <!-- Total itens -->
                                                        <div
                                                            class="col-lg-4 col-md-6 mb-2">

                                                            <div
                                                                class="border rounded p-3 h-100">

                                                                <span
                                                                    class="text-muted small">

                                                                    Total dos Itens

                                                                </span>


                                                                <div
                                                                    class="fw-bold fs-5">

                                                                    R$

                                                                    <?= number_format(
                                                                        $itemsTotal,
                                                                        2,
                                                                        ',',
                                                                        '.'
                                                                    ); ?>

                                                                </div>

                                                            </div>

                                                        </div>


                                                        <!-- Diferença -->
                                                        <div
                                                            class="col-lg-4 col-md-6 mb-2">

                                                            <div
                                                                class="border rounded p-3 h-100">

                                                                <span
                                                                    class="text-muted small">

                                                                    Diferença

                                                                </span>


                                                                <div
                                                                    class="fw-bold fs-5
                                                                    <?= $stageDifference < 0
                                                                        ? 'text-danger'
                                                                        : 'text-success'; ?>">

                                                                    R$

                                                                    <?= number_format(
                                                                        $stageDifference,
                                                                        2,
                                                                        ',',
                                                                        '.'
                                                                    ); ?>

                                                                </div>

                                                            </div>

                                                        </div>

                                                    </div>


                                                    <!-- ================== -->
                                                    <!-- COMPOSIÇÃO ETAPA    -->
                                                    <!-- ================== -->

                                                    <div class="mb-4">

                                                        <div
                                                            class="d-flex justify-content-between mb-1">

                                                            <span class="small">

                                                                Composição da etapa

                                                            </span>


                                                            <span class="small">

                                                                <?= number_format(
                                                                    $stagePercent,
                                                                    1,
                                                                    ',',
                                                                    '.'
                                                                ); ?>%

                                                            </span>

                                                        </div>


                                                        <div
                                                            class="progress"
                                                            style="height: 10px;">

                                                            <div
                                                                class="progress-bar"
                                                                role="progressbar"
                                                                style="width: <?= $stageProgress; ?>%;">

                                                            </div>

                                                        </div>

                                                    </div>


                                                    <!-- ================== -->
                                                    <!-- ITENS DA ETAPA      -->
                                                    <!-- ================== -->

                                                    <?php if (
                                                        !empty($stage['items'])
                                                    ): ?>


                                                        <div
                                                            class="table-responsive">


                                                            <table
                                                                class="table table-striped
                                                                       table-hover
                                                                       align-middle
                                                                       mb-0">


                                                                <!-- Cabeçalho -->
                                                                <thead>

                                                                    <tr>

                                                                        <th scope="col">

                                                                            Código

                                                                        </th>


                                                                        <th scope="col">

                                                                            Descrição

                                                                        </th>


                                                                        <th
                                                                            scope="col"
                                                                            class="text-center">

                                                                            Unidade

                                                                        </th>


                                                                        <th
                                                                            scope="col"
                                                                            class="text-end">

                                                                            Quantidade

                                                                        </th>


                                                                        <th
                                                                            scope="col"
                                                                            class="text-end">

                                                                            Preço Unitário

                                                                        </th>


                                                                        <th
                                                                            scope="col"
                                                                            class="text-end">

                                                                            Valor Orçado

                                                                        </th>

                                                                    </tr>

                                                                </thead>


                                                                <!-- Corpo -->
                                                                <tbody>


                                                                    <?php foreach (
                                                                        $stage['items']
                                                                        as $item
                                                                    ): ?>


                                                                        <tr>


                                                                            <!-- Código -->
                                                                            <td>

                                                                                <?= htmlspecialchars(
                                                                                    $item['code']
                                                                                        ?? ''
                                                                                ); ?>

                                                                            </td>


                                                                            <!-- Descrição -->
                                                                            <td>

                                                                                <?= htmlspecialchars(
                                                                                    $item['description']
                                                                                        ?? ''
                                                                                ); ?>

                                                                            </td>


                                                                            <!-- Unidade -->
                                                                            <td
                                                                                class="text-center">

                                                                                <?= htmlspecialchars(
                                                                                    $item['measurement_unit_name']
                                                                                        ?? '-'
                                                                                ); ?>

                                                                            </td>


                                                                            <!-- Quantidade -->
                                                                            <td
                                                                                class="text-end">

                                                                                <?= number_format(
                                                                                    (float) (
                                                                                        $item['quantity']
                                                                                        ?? 0
                                                                                    ),
                                                                                    2,
                                                                                    ',',
                                                                                    '.'
                                                                                ); ?>

                                                                            </td>


                                                                            <!-- Preço Unitário -->
                                                                            <td
                                                                                class="text-end">

                                                                                R$

                                                                                <?= number_format(
                                                                                    (float) (
                                                                                        $item['unit_price']
                                                                                        ?? 0
                                                                                    ),
                                                                                    2,
                                                                                    ',',
                                                                                    '.'
                                                                                ); ?>

                                                                            </td>


                                                                            <!-- Valor -->
                                                                            <td
                                                                                class="text-end fw-semibold">

                                                                                R$

                                                                                <?= number_format(
                                                                                    (float) (
                                                                                        $item['budget_value']
                                                                                        ?? 0
                                                                                    ),
                                                                                    2,
                                                                                    ',',
                                                                                    '.'
                                                                                ); ?>

                                                                            </td>

                                                                        </tr>


                                                                    <?php endforeach; ?>


                                                                </tbody>


                                                                <!-- Rodapé -->
                                                                <tfoot>

                                                                    <tr>

                                                                        <td
                                                                            colspan="5"
                                                                            class="text-end fw-bold">

                                                                            Total:

                                                                        </td>


                                                                        <td
                                                                            class="text-end fw-bold">

                                                                            R$

                                                                            <?= number_format(
                                                                                $itemsTotal,
                                                                                2,
                                                                                ',',
                                                                                '.'
                                                                            ); ?>

                                                                        </td>

                                                                    </tr>

                                                                </tfoot>

                                                            </table>

                                                        </div>


                                                    <?php else: ?>


                                                        <div class="d-flex align-items-center gap-2">

                                                            <!-- Alerta -->
                                                            <div
                                                                class="alert alert-warning mb-0 flex-grow-1"
                                                                role="alert">

                                                                <i class="fa-solid fa-triangle-exclamation me-1"></i>

                                                                Nenhum item cadastrado nesta etapa.

                                                            </div>

                                                        </div>

                                                    <?php endif; ?>

                                                    <!-- Botão -->
                                                    <div class="mt-2 text-end">

                                                        <a
                                                            href="<?= $_ENV['URL_ADM']
                                                                        . 'create-budget-items/'
                                                                        . (int) $stage['budget_stage_id']; ?>"
                                                            class="btn btn-success btn-sm">

                                                            <i class="fa-solid fa-circle-plus"></i>
                                                            Item

                                                        </a>

                                                    </div>

                                                </div>
                                                <!-- /accordion-body -->


                                            </div>
                                            <!-- /accordion-collapse -->


                                        </div>
                                        <!-- /accordion-item -->


                                    <?php endforeach; ?>


                                </div>
                                <!-- /accordion -->


                            <?php else: ?>


                                <div
                                    class="alert alert-warning mb-0"
                                    role="alert">

                                    <i
                                        class="fa-solid fa-triangle-exclamation me-1">
                                    </i>

                                    Nenhuma etapa encontrada
                                    para este orçamento.

                                </div>


                            <?php endif; ?>


                        </div>
                        <!-- /card-body etapas -->


                    </div>
                    <!-- /card etapas -->


                </div>
                <!-- /card-body mestre -->


            </div>
            <!-- /card mestre -->


        <?php endforeach; ?>


    <?php else: ?>


        <div
            class="alert alert-danger"
            role="alert">

            <i
                class="fa-solid fa-circle-exclamation me-1">
            </i>

            Nenhum orçamento encontrado.

        </div>


    <?php endif; ?>


</div>