<?php

use App\admsDaman\Helpers\CSRFHelper;

$projects = $this->data['projects'] ?? [];
$form = $this->data['form'] ?? [];

// Recuperar etapas em caso de retorno do formulário.
// Se não houver, inicia com uma etapa vazia.
$stages = $form['stages'] ?? [
    [
        'code' => '',
        'name' => '',
        'budget_value' => '',
        'sort_order' => 1,
    ]
];

?>

<div class="container-fluid px-4">

    <!-- Título e Breadcrumb -->
    <div class="mb-1 hstack gap-2">

        <h2 class="mt-3">Orçamentos</h2>

        <ol class="breadcrumb mb-3 mt-3 ms-auto">

            <li class="breadcrumb-item">
                <a
                    class="text-decoration-none"
                    href="<?= $_ENV['URL_ADM']; ?>dashboard">
                    Dashboard
                </a>
            </li>

            <li class="breadcrumb-item">
                <a
                    class="text-decoration-none"
                    href="<?= $_ENV['URL_ADM']; ?>list-budgets">
                    Orçamentos
                </a>
            </li>

            <li
                class="breadcrumb-item active"
                aria-current="page">
                Cadastrar
            </li>

        </ol>

    </div>


    <div class="card mb-4 border-light shadow">

        <!-- Cabeçalho -->
        <div class="card-header hstack gap-2">

            <span>
                <i class="fa-solid fa-file-invoice-dollar me-1"></i>
                Cadastrar Orçamento
            </span>

            <span class="ms-auto d-sm-flex flex-row">

                <?php if (in_array(
                    "ListBudgets",
                    $this->data['buttonPermissions'] ?? []
                )): ?>

                    <a
                        href="<?= $_ENV['URL_ADM']; ?>list-budgets"
                        class="btn btn-info btn-sm me-1 mb-1">

                        <i class="fa-solid fa-list"></i>
                        Listar

                    </a>

                <?php endif; ?>

            </span>

        </div>


        <div class="card-body">

            <?php

            // Incluir arquivo responsável pelos alertas
            include './app/admsDaman/Views/partials/alerts.php';

            ?>


            <form
                action=""
                method="POST"
                class="row g-3"
                id="formCreateBudget">

                <!-- CSRF -->
                <input type="hidden" name="csrf_token" value="<?= CSRFHelper::generateCSRFToken( 'form_create_budget'); ?>">
                <input type="hidden" class="form-control" id="adms_daman_user_id" name="adms_daman_user_id"
                        value="<?= $_SESSION['user_id'] ?? ''; ?>" placeholder="Id do usuário">


                <!-- ============================= -->
                <!-- DADOS PRINCIPAIS DO ORÇAMENTO -->
                <!-- ============================= -->

                <div class="col-12">

                    <h5 class="border-bottom pb-2 mb-3">

                        <i class="fa-solid fa-building me-1"></i>
                        Dados do Orçamento

                    </h5>

                </div>


                <!-- Obra -->
                <div class="col-md-8">

                    <label
                        for="adms_daman_project_id"
                        class="form-label">

                        Obra:
                    </label>

                    <select name="adms_daman_project_id" class="form-select" id="adms_daman_project_id">
                        <option value="" selected>Selecione</option>

                        <?php
                        // Verificar se existe pacotes
                        if ($this->data['getAllProjectsSelectActive'] ?? false) {

                            // Percorrer array de pacotes
                            foreach ($this->data['getAllProjectsSelectActive'] as $getAllProjectsSelectActive) {
                                extract($getAllProjectsSelectActive);

                                // Verificar se deve manter selecionada a opção
                                $selected = isset($this->data['form']['adms_daman_project_id']) && $this->data['form']['adms_daman_project_id'] == $id ? 'selected' : '';

                                echo "<option value='$id' $selected>$name</option>";
                            }
                        }
                        ?>
                    </select>

                </div>


                <!-- Valor total -->
                <div class="col-md-4">

                    <label
                        for="total_budget"
                        class="form-label">

                        Orçamento Total:
                    </label>

                    <div class="input-group">

                        <span class="input-group-text">
                            R$
                        </span>

                        <input
                            type="text"
                            class="form-control"
                            id="total_budget"
                            name="total_budget"
                            inputmode="decimal"
                            value="<?= htmlspecialchars(
                                        $form['total_budget'] ?? ''
                                    ); ?>"
                            placeholder="0,00">

                    </div>

                </div>


                <!-- Informação -->
                <div class="col-12">

                    <div class="alert alert-info py-2 mb-0">

                        <i class="fa-solid fa-circle-info me-1"></i>

                        O orçamento será cadastrado inicialmente como
                        <strong>Rascunho</strong>.

                    </div>

                </div>


                <!-- ================== -->
                <!-- ETAPAS DO ORÇAMENTO -->
                <!-- ================== -->

                <div class="col-12 mt-4">

                    <div
                        class="d-flex flex-column flex-sm-row
                               align-items-sm-center gap-2
                               border-bottom pb-2">

                        <h5 class="mb-0">

                            <i class="fa-solid fa-layer-group me-1"></i>
                            Etapas do Orçamento

                        </h5>


                        <button
                            type="button"
                            class="btn btn-success btn-sm ms-sm-auto"
                            id="btnAddStage">

                            <i class="fa-solid fa-circle-plus"></i>
                            Adicionar Etapa

                        </button>

                    </div>

                </div>


                <!-- Resumo -->
                <div class="col-12">

                    <div class="row g-2">

                        <div class="col-md-4">

                            <div
                                class="border rounded p-2 h-100">

                                <small class="text-muted">
                                    Orçamento total
                                </small>

                                <div
                                    class="fw-bold"
                                    id="summaryTotalBudget">

                                    R$ 0,00

                                </div>

                            </div>

                        </div>


                        <div class="col-md-4">

                            <div
                                class="border rounded p-2 h-100">

                                <small class="text-muted">
                                    Distribuído nas etapas
                                </small>

                                <div
                                    class="fw-bold"
                                    id="summaryDistributed">

                                    R$ 0,00

                                </div>

                            </div>

                        </div>


                        <div class="col-md-4">

                            <div
                                class="border rounded p-2 h-100">

                                <small class="text-muted">
                                    Não distribuído
                                </small>

                                <div
                                    class="fw-bold"
                                    id="summaryRemaining">

                                    R$ 0,00

                                </div>

                            </div>

                        </div>

                    </div>

                </div>


                <!-- Container das etapas -->
                <div
                    class="col-12"
                    id="stagesContainer">

                    <?php foreach ($stages as $index => $stage): ?>

                        <div
                            class="stage-row border rounded p-3 mb-3"
                            data-index="<?= $index; ?>">

                            <div
                                class="d-flex align-items-center mb-3">

                                <strong class="stage-title">

                                    Etapa
                                    <?= $index + 1; ?>

                                </strong>


                                <button
                                    type="button"
                                    class="btn btn-danger btn-sm ms-auto
                                           btn-remove-stage">

                                    <i class="fa-solid fa-trash"></i>
                                    Remover

                                </button>

                            </div>


                            <div class="row g-3">

                                <div class="col-md-8">

                                    <label class="form-label">
                                        Etapa:
                                    </label>

                                    <select
                                        name="stages[<?= $index; ?>][adms_daman_stage_id]"
                                        class="form-select stage-select">

                                        <option value="">
                                            Selecione
                                        </option>

                                        <?php

                                        // Verificar se existem etapas ativas
                                        if ($this->data['getAllStages'] ?? false) {

                                            // Percorrer as etapas cadastradas
                                            foreach (
                                                $this->data['getAllStages']
                                                as $stageOption
                                            ) {

                                                // Verificar se deve manter selecionada
                                                // a etapa após retorno do formulário
                                                $selected =
                                                    isset($stage['adms_daman_stage_id'])
                                                    && $stage['adms_daman_stage_id'] == $stageOption['id']
                                                    ? 'selected'
                                                    : '';

                                                echo "<option
                        value='" . (int) $stageOption['id'] . "'
                        $selected>"
                                                    . htmlspecialchars($stageOption['code'])
                                                    . " - "
                                                    . htmlspecialchars($stageOption['name'])
                                                    . "</option>";
                                            }
                                        }

                                        ?>

                                    </select>

                                </div>


                                <!-- Valor -->
                                <div class="col-md-4">

                                    <label class="form-label">
                                        Valor Orçado:
                                    </label>

                                    <div class="input-group">

                                        <span class="input-group-text">
                                            R$
                                        </span>

                                        <input
                                            type="text"
                                            class="form-control
                                                   stage-budget-value"
                                            name="stages[<?= $index; ?>][budget_value]"
                                            inputmode="decimal"
                                            value="<?= htmlspecialchars(
                                                        $stage['budget_value'] ?? ''
                                                    ); ?>"
                                            placeholder="0,00">

                                    </div>

                                </div>


                                <!-- Ordem automática -->
                                <input
                                    type="hidden"
                                    class="stage-sort-order"
                                    name="stages[<?= $index; ?>][sort_order]"
                                    value="<?= $index + 1; ?>">

                            </div>

                        </div>

                    <?php endforeach; ?>

                </div>


                <!-- Botão submit -->
                <div class="col-12">

                    <button
                        type="submit"
                        name="AddBudget"
                        value="Cadastrar"
                        class="btn btn-primary btn-sm">

                        <i class="fa-solid fa-floppy-disk"></i>
                        Cadastrar Orçamento

                    </button>

                </div>

            </form>

            <!-- Disponibilizar as etapas do banco para o JavaScript externo -->
            <div
                id="stages-data"
                data-stages='<?= htmlspecialchars(
                                    json_encode(
                                        $this->data['getAllStages'] ?? []
                                    ),
                                    ENT_QUOTES,
                                    'UTF-8'
                                ); ?>'
                data-old-stages='<?= htmlspecialchars(
                                        json_encode(
                                            $this->data['form']['stages'] ?? []
                                        ),
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ); ?>'>
            </div>

        </div>

    </div>

</div>