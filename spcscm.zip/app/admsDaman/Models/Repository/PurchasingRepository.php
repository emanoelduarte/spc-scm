<?php

namespace App\admsDaman\Models\Repository;

use App\admsDaman\Helpers\GenerateLog;
use App\admsDaman\Helpers\NormalizeDecimal;
use App\admsDaman\Models\Services\DbConnection;
use DateTime;
use Exception;
use PDO;

class PurchasingRepository extends DbConnection
{
    /**
     * Recuperar todas as compras com paginação e filtros.
     *
     * Calcula o subtotal dos itens, desconto, frete e total da compra.
     *
     * @param int $page Número da página.
     * @param int $limitResult Quantidade de registros por página.
     * @param array|null $filters Filtros da pesquisa.
     * @return array|false Lista de compras.
     */
    public function getAllPurchasings(int $page = 1, int $limitResult = 10, ?array $filters = []): array|false
    {
        // Calcular o offset da paginação
        $limitResult = max(1, $limitResult);
        $offset = max(0, ($page - 1) * $limitResult);
    
        $conditions = [];
        $params = [];
    
        // Mapear os filtros para suas respectivas colunas
        $map = [
            'purchasing_number' => 'adpu.id',
            'order_number' => 'adpu.adms_daman_order_id',
            'adms_daman_project_id' => 'adpu.adms_daman_project_id',
            'adms_daman_category_id' => 'adpu.adms_daman_category_id',
            'adms_daman_acquisition_purchasing_status_id' => 'adpu.adms_daman_acquisition_purchasing_status_id',
        ];
    
        foreach ($map as $field => $column) {
            if (isset($filters[$field]) && $filters[$field] !== '') {
                $conditions[] = "{$column} = :{$field}";
                $params[$field] = $filters[$field];
            }
        }
    
        // Filtrar por data inicial
        if (!empty($filters['data_inicio'])) {
            $conditions[] = "adpu.created_at >= :data_inicio";
            $params['data_inicio'] = $filters['data_inicio'] . ' 00:00:00';
        }
    
        // Filtrar por data final
        if (!empty($filters['data_fim'])) {
            $conditions[] = "adpu.created_at <= :data_fim";
            $params['data_fim'] = $filters['data_fim'] . ' 23:59:59';
        }
    
        // Filtrar pelo nome do fornecedor
        if (!empty($filters['legal_name'])) {
            $conditions[] = "ads.legal_name LIKE :legal_name";
            $params['legal_name'] = '%' . $filters['legal_name'] . '%';
        }
    
        $where = !empty($conditions) ? 'WHERE ' . implode(' AND ', $conditions) : '';
    
        // Recuperar as compras com seus respectivos valores
        $sql = "SELECT
                    adpu.id,
                    adpu.adms_daman_order_id,
                    adpu.created_at,
    
                    adp.name AS project_name,
                    ads.trade_name,
                    adu.name AS buyer_name,
                    adaps.id AS purchasing_status_id,
                    adaps.name AS purchasing_status,
    
                    COALESCE(totals.subtotal, 0) AS subtotal,
                    COALESCE(adpu.discount, 0) AS discount,
                    COALESCE(adpu.delivery_value, 0) AS delivery_value,
    
                    (
                        COALESCE(totals.subtotal, 0)
                        - COALESCE(adpu.discount, 0)
                        + COALESCE(adpu.delivery_value, 0)
                    ) AS total_purchase
    
                FROM adms_daman_purchasings AS adpu
    
                INNER JOIN adms_daman_suppliers AS ads
                    ON ads.id = adpu.adms_daman_supplier_id
    
                INNER JOIN adms_daman_projects AS adp
                    ON adp.id = adpu.adms_daman_project_id
    
                INNER JOIN adms_daman_users AS adu
                    ON adu.id = adpu.adms_daman_user_id
    
                INNER JOIN adms_daman_acquisition_purchasing_status AS adaps
                    ON adaps.id = adpu.adms_daman_acquisition_purchasing_status_id
    
                LEFT JOIN (
                    SELECT
                        adms_daman_purchasing_id,
                        SUM(purchased_quantity * unit_price) AS subtotal
                    FROM adms_daman_purchasing_items
                    GROUP BY adms_daman_purchasing_id
                ) AS totals ON totals.adms_daman_purchasing_id = adpu.id
    
                {$where}
    
                ORDER BY adpu.id DESC
                LIMIT :limit OFFSET :offset";
    
        // Preparar a consulta
        $stmt = $this->getConnection()->prepare($sql);
    
        // Vincular os parâmetros dos filtros
        foreach ($params as $key => $value) {
            $stmt->bindValue(
                ":{$key}",
                $value,
                is_int($value) || (is_string($value) && ctype_digit($value))
                    ? PDO::PARAM_INT
                    : PDO::PARAM_STR
            );
        }
    
        // Vincular os parâmetros da paginação
        $stmt->bindValue(':limit', $limitResult, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    
        // Executar a consulta
        $stmt->execute();
    
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }


    
    /**
     * Recuperar a quantidade total de compras conforme os filtros.
     *
     * Utilizado para calcular a paginação da listagem.
     *
     * @param array|null $filters Filtros da pesquisa.
     * @return int Quantidade de compras encontradas.
     */
    public function getAmountPurchasings(?array $filters = []): int
    {
        $conditions = [];
        $params = [];
    
        // Mapear os filtros para suas respectivas colunas
        $map = [
            'purchasing_number' => 'adpu.id',
            'order_number' => 'adpu.adms_daman_order_id',
            'adms_daman_project_id' => 'adpu.adms_daman_project_id',
            'adms_daman_category_id' => 'adpu.adms_daman_category_id',
            'adms_daman_acquisition_purchasing_status_id' => 'adpu.adms_daman_acquisition_purchasing_status_id',
        ];
    
        foreach ($map as $field => $column) {
            if (isset($filters[$field]) && $filters[$field] !== '') {
                $conditions[] = "{$column} = :{$field}";
                $params[$field] = $filters[$field];
            }
        }
    
        // Filtrar por data inicial
        if (!empty($filters['data_inicio'])) {
            $conditions[] = "adpu.created_at >= :data_inicio";
            $params['data_inicio'] = $filters['data_inicio'] . ' 00:00:00';
        }
    
        // Filtrar por data final
        if (!empty($filters['data_fim'])) {
            $conditions[] = "adpu.created_at <= :data_fim";
            $params['data_fim'] = $filters['data_fim'] . ' 23:59:59';
        }
    
        // Filtrar pelo nome do fornecedor
        if (!empty($filters['legal_name'])) {
            $conditions[] = "ads.legal_name LIKE :legal_name";
            $params['legal_name'] = '%' . $filters['legal_name'] . '%';
        }
    
        $where = !empty($conditions) ? 'WHERE ' . implode(' AND ', $conditions) : '';
    
        // Contar as compras encontradas
        $sql = "SELECT COUNT(adpu.id) AS amount_records
                FROM adms_daman_purchasings AS adpu
    
                INNER JOIN adms_daman_suppliers AS ads
                    ON ads.id = adpu.adms_daman_supplier_id
    
                INNER JOIN adms_daman_projects AS adp
                    ON adp.id = adpu.adms_daman_project_id
    
                INNER JOIN adms_daman_users AS adu
                    ON adu.id = adpu.adms_daman_user_id
    
                INNER JOIN adms_daman_acquisition_purchasing_status AS adaps
                    ON adaps.id = adpu.adms_daman_acquisition_purchasing_status_id
    
                {$where}";
    
        // Preparar a consulta
        $stmt = $this->getConnection()->prepare($sql);
    
        // Vincular os parâmetros
        foreach ($params as $key => $value) {
            $stmt->bindValue(
                ":{$key}",
                $value,
                is_int($value) || (is_string($value) && ctype_digit($value))
                    ? PDO::PARAM_INT
                    : PDO::PARAM_STR
            );
        }
    
        // Executar a consulta
        $stmt->execute();
    
        return (int) ($stmt->fetch(PDO::FETCH_ASSOC)['amount_records'] ?? 0);
    }

    /**
     * Recuperar uma compra específica com seus respectivos itens
     * 
     * @return array|bool compra recuperado do banco de dados
     */

    public function getPurchasing(int $idPurchasing): array|bool
    {

        try {
            $sql = 'SELECT adpu.id, adpu.expected_receipt_date, adpu.service, adpu.delivery_address, adpu.delivery_value, adpu.discount, adpu.created_at, adpu.updated_at,
                adp.name AS project_name,
                ads.legal_name,
                ado.id AS order_number,
                adu.name AS buyer_name,
                adpm.name AS payment_method,
                adat.name AS acquisition_type,
                adaps.id AS purchasing_status_id,
                adaps.name AS purchasing_status
        FROM adms_daman_purchasings AS adpu
        INNER JOIN adms_daman_suppliers AS ads ON ads.id = adpu.adms_daman_supplier_id
        INNER JOIN adms_daman_projects AS adp ON adp.id = adpu.adms_daman_project_id
        INNER JOIN adms_daman_orders AS ado ON ado.id = adpu.adms_daman_order_id
        INNER JOIN adms_daman_users AS adu ON adu.id = adpu.adms_daman_user_id 
        INNER JOIN adms_daman_payment_methods AS adpm ON adpm.id = adpu.adms_daman_payment_methods_id 
        INNER JOIN adms_daman_acquisition_types AS adat ON adat.id = adpu.adms_daman_acquisition_types_id 
        INNER JOIN adms_daman_acquisition_purchasing_status AS adaps ON adaps.id = adpu.adms_daman_acquisition_purchasing_status_id 
        WHERE adpu.id = :id';

            // Preparar a query
            $stmt = $this->getConnection()->prepare($sql);

            //Substituir Links
            $stmt->bindValue(':id', $idPurchasing, PDO::PARAM_INT);

            // Executar a Query
            $stmt->execute();

            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $err) {
            GenerateLog::generateLog("error", "Compra não encontrada", ['id' => (int) $idPurchasing]);
            die("Compra não encontrada!" . $err->getMessage());
        }
        return false;
    }

    /**
     * Método para buscar os itens da Compra
     */
    public function getItems(int $idPurchasing): array|bool
    {

        try {

            $sql = "SELECT adpi.adms_daman_purchasing_id, adpi.adms_daman_measurement_units_id, adpi.description, adpi.purchased_quantity, adpi.unit_price, adpi.created_at, adpi.updated_at,
                admu.name AS measurement_unit
                FROM adms_daman_purchasing_items AS adpi
                INNER JOIN adms_daman_measurement_units AS admu ON admu.id=adpi.adms_daman_measurement_units_id
                WHERE adms_daman_purchasing_id = :idPurchasing";

            $stmt = $this->getConnection()->prepare($sql);

            $stmt->bindValue(':idPurchasing', $idPurchasing, PDO::PARAM_INT);

            $stmt->execute();

            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) { // Acessa o catch quando houver erro no try

            // Chamar o método para salvar o log
            GenerateLog::generateLog("error", "O pedido não possui itens.", ['name' => $_SESSION['user_name'], 'error' => $e->getMessage()]);

            return false;
        }

        return false;
    }

    public function generatePurchasing(array $data): int|bool
    {

        try {
            // $FormatedDate = DateTime::createFromFormat('d/m/Y', $data['expected_receipt_date'])->format('Y-m-d');


            $sql = 'INSERT INTO adms_daman_purchasings 
                    (adms_daman_supplier_id, adms_daman_user_id, adms_daman_acquisition_types_id, adms_daman_acquisition_purchasing_status_id, expected_receipt_date, adms_daman_order_id, adms_daman_project_id, service, delivery_address, adms_daman_payment_methods_id, created_at';

            if (!$data['delivery_value'] == '') {
                $sql .= ', delivery_value';
            }

            if (!$data['discount'] == '') {
                $sql .= ', discount';
            }
            $sql .= ') VALUES (:adms_daman_supplier_id, :adms_daman_user_id, :adms_daman_acquisition_types_id, :adms_daman_acquisition_purchasing_status_id, :expected_receipt_date, :adms_daman_order_id, :adms_daman_project_id, :service, :delivery_address, :adms_daman_payment_methods_id, :created_at';

            if (!$data['delivery_value'] == '') {
                $sql .= ', :delivery_value';
            }

            if (!$data['discount'] == '') {
                $sql .= ', :discount';
            }

            $sql .= ')';

            $stmt = $this->getConnection()->prepare($sql);

            $stmt->bindValue(':adms_daman_supplier_id', $data['adms_daman_supplier_id'], PDO::PARAM_INT);
            $stmt->bindValue(':adms_daman_user_id', $data['adms_daman_user_id'], PDO::PARAM_INT);
            $stmt->bindValue(':adms_daman_acquisition_types_id', $data['adms_daman_acquisition_types_id'], PDO::PARAM_INT);
            $stmt->bindValue(':adms_daman_acquisition_purchasing_status_id', 1, PDO::PARAM_INT);
            $stmt->bindValue(':expected_receipt_date', $data['expected_receipt_date']);
            $stmt->bindValue(':adms_daman_order_id', $data['adms_daman_order_id'], PDO::PARAM_INT);
            $stmt->bindValue(':adms_daman_project_id', $data['adms_daman_project_id'], PDO::PARAM_INT);
            $stmt->bindValue(':service', $data['service'], PDO::PARAM_STR);
            $stmt->bindValue(':delivery_address', $data['delivery_address'], PDO::PARAM_STR);
            $stmt->bindValue(':adms_daman_payment_methods_id', $data['adms_daman_payment_methods_id'], PDO::PARAM_INT);
            $stmt->bindValue(':created_at', date("Y-m-d H:i:s"));


            if (!$data['delivery_value'] == '') {
                $stmt->bindValue(':delivery_value', NormalizeDecimal::normalizeDecimal($data['delivery_value']));
            }
            if (!$data['discount'] == '') {
                $stmt->bindValue(':discount', NormalizeDecimal::normalizeDecimal($data['discount']));
            }

            // Executar a QUERY
            $result = $stmt->execute();


            if ($result) {
                // 2. PEGA O ID AQUI (imediatamente após o insert do pedido)
                $purchasingId = $this->getConnection()->lastInsertId();

                // Chama o método para cadastar os itens
                $this->generateItemsPurchasing($data, $purchasingId);
            }

            // retorna o ultimo id inserido de pedido
            return $purchasingId;
        } catch (Exception $e) { // Acessa o catch quando houver erro no try

            // Chamar o método para salvar o log
            GenerateLog::generateLog("error", "Compra não cadastrada.", ['name' => $_SESSION['user_name'], 'error' => $e->getMessage()]);

            return false;
        }
    }

    public function generateItemsPurchasing(array $dataForm, $purchasingId): bool
    {

        try {

            foreach ($dataForm['items'] as $item) {

                $sql = 'INSERT INTO adms_daman_purchasing_items 
            (
                adms_daman_purchasing_id,
                description,
                adms_daman_measurement_units_id,
                purchased_quantity,
                unit_price,
                created_at
            ) 
            VALUES
            (
                :adms_daman_purchasing_id,
                :description,
                :adms_daman_measurement_units_id,
                :purchased_quantity,
                :unit_price,
                :created_at
            )';

                $stmt = $this->getConnection()->prepare($sql);

                $stmt->bindValue(
                    ':adms_daman_purchasing_id',
                    $purchasingId,
                    PDO::PARAM_INT
                );

                $stmt->bindValue(
                    ':description',
                    $item['description'],
                    PDO::PARAM_STR
                );

                $stmt->bindValue(
                    ':adms_daman_measurement_units_id',
                    (int)$item['adms_daman_measurement_units_id'],
                    PDO::PARAM_INT
                );

                $stmt->bindValue(
                    ':purchased_quantity',
                    (float)$item['purchased_quantity']
                );

                $stmt->bindValue(
                    ':unit_price',
                    (float)$item['unit_price']
                );

                $stmt->bindValue(
                    ':created_at',
                    date('Y-m-d H:i:s')
                );

                $stmt->execute();
            }

            return true;
        } catch (Exception $e) {

            GenerateLog::generateLog(
                "error",
                "Itens não cadastrados.",
                [
                    'name' => $_SESSION['user_name'],
                    'error' => $e->getMessage()
                ]
            );

            return false;
        }
    }

    /**
     * Metodo para Cancelar a Compra
     */
    public function updateCancelPurchasing(int $idPurchasing): bool
    {
        try {

            $sql = "UPDATE adms_daman_purchasings SET adms_daman_acquisition_purchasing_status_id = :adms_daman_acquisition_purchasing_status_id, updated_at = :updated_at
        WHERE id = :id";

            // Preparar a QUERY
            $stmt = $this->getConnection()->prepare($sql);

            // Substituir os links da QUERY pelo valor
            $stmt->bindValue(':adms_daman_acquisition_purchasing_status_id', 2, PDO::PARAM_INT);
            $stmt->bindValue(':updated_at', date("Y-m-d H:i:s"));
            $stmt->bindValue(':id', $idPurchasing, PDO::PARAM_INT);

            // Executar a QUERY
            $stmt->execute();

            // Verificar o número de linhas afetadas
            if ($stmt->rowCount() > 0) {
                return true;
            } else {

                // Chamar o método para salvar o log
                GenerateLog::generateLog("error", "Compra não cancelada.", ['id_compra' => $idPurchasing]);

                return false;
            }
        } catch (Exception $e) {
            // Chamar o método para salvar o log
            GenerateLog::generateLog("error", "Compra não cancelada.", ['name' => $_SESSION['user_name'], 'error' => $e->getMessage()]);

            return false;
        }
    }

    /**
     * Método para deletar compras
     */
    public function deletePurchasing(int $idPurchasing): bool
    {
        // Usar o try e catch para gerenciar exceção/erro
        try {

            // Query para deletar o compra
            $sql = 'DELETE FROM adms_daman_purchasings  WHERE id = :id LIMIT 1';

            // Preparar a Query
            $stmt = $this->getConnection()->prepare($sql);

            // Substiruir os links pelo valor
            $stmt->bindParam(':id', $idPurchasing, PDO::PARAM_INT);

            // Executar a Query
            $stmt->execute();

            // Verificar o número de linhas afetadas
            $affectedRows = $stmt->rowCount();

            if ($affectedRows > 0) {
                return true;
            } else {
                // Chamar o método para salvar o log
                GenerateLog::generateLog("error", "Pedido não apagado.", ['id' => $idPurchasing]);
                return false;
            }
        } catch (Exception $e) {

            // Chamar o método para salvar o log
            GenerateLog::generateLog("error", "Compra não apagada.", ['id' => $idPurchasing, 'error' => $e->getMessage()]);

            return false;
        }
    }

    /**
     * Recuperar uma obra específica
     * 
     * @return array|bool Obra recuperada do banco de dados
     */
    public function getAllPurchasingStatusSelect(): array|bool
    {
        // QUERY para recuperar os registros do banco de dados
        $sql = 'SELECT id, name 
                FROM adms_daman_acquisition_purchasing_status
                ORDER BY id ASC';

        // Preparar a QUERY
        $stmt = $this->getConnection()->prepare($sql);

        // Executar a QUERY
        $stmt->execute();

        // Ler os registros e retornar 
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Método para recuperar as 5 últimas compras realizadas durante a semana, busca na tabela de itens pelos valores unitários e quantidades compradas para calcular o valor total da compra, e se houver valor de entrega e desconto, subtrai ou soma ao valor total da compra, retornando o valor final da compra.
     * @return array|bool Lista de compras recuperados do banco de dados
     */
    public function getLastPurchasingsWeek(): array|bool
    {
        $sql = "SELECT 
                adpu.id,
                adpu.created_at,
                adpu.service,

                SUM(adpi.purchased_quantity * adpi.unit_price) AS subtotal,

                COALESCE(adpu.discount, 0) AS discount,
                COALESCE(adpu.delivery_value, 0) AS delivery_value,

                (
                    SUM(adpi.purchased_quantity * adpi.unit_price)
                    + COALESCE(adpu.delivery_value, 0)
                    - COALESCE(adpu.discount, 0)
                ) AS total_final,

                adp.name AS project_name,
                ads.legal_name AS supplier_name

            FROM adms_daman_purchasings AS adpu

            INNER JOIN adms_daman_projects AS adp 
                ON adp.id = adpu.adms_daman_project_id

            INNER JOIN adms_daman_suppliers AS ads 
                ON ads.id = adpu.adms_daman_supplier_id

            INNER JOIN adms_daman_purchasing_items AS adpi 
                ON adpi.adms_daman_purchasing_id = adpu.id

            WHERE 
                adpu.created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
                AND adpu.adms_daman_acquisition_purchasing_status_id = 1

            GROUP BY 
                adpu.id,
                adpu.created_at,
                adpu.service,
                adp.name,
                ads.legal_name

            ORDER BY adpu.created_at DESC

            LIMIT 10";

        $stmt = $this->getConnection()->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getTotalPurchasingsWeek(): float|bool
    {
        $sql = "SELECT SUM(total_final) AS total_week
            FROM (
                SELECT 
                    (
                        SUM(adpi.purchased_quantity * adpi.unit_price)
                        + COALESCE(adpu.delivery_value, 0)
                        - COALESCE(adpu.discount, 0)
                    ) AS total_final

                FROM adms_daman_purchasings AS adpu

                INNER JOIN adms_daman_purchasing_items AS adpi 
                    ON adpi.adms_daman_purchasing_id = adpu.id

                WHERE 
                    adpu.created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
                    AND adpu.adms_daman_acquisition_purchasing_status_id = 1

                GROUP BY adpu.id
            ) AS totals";

        $stmt = $this->getConnection()->prepare($sql);
        $stmt->execute();

        return (float) $stmt->fetchColumn();
    }
}
