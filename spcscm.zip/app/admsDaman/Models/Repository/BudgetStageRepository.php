<?php

namespace App\admsDaman\Models\Repository;

use App\admsDaman\Models\Services\DbConnection;
use PDO;

class BudgetStageRepository extends DbConnection
{
    /**
     * Cadastrar as etapas vinculadas a um orçamento.
     *
     * @param int $budgetId ID do orçamento recém-cadastrado.
     * @param array $stages Etapas recebidas do formulário.
     * @return bool
     */
    public function createBudgetStages(
        int $budgetId,
        array $stages
    ): bool {

        // Nenhuma etapa recebida.
        if (empty($stages)) {
            return false;
        }


        // Recuperar conexão.
        $connection = $this->getConnection();


        // Preparar a query uma única vez.
        //
        // Ela será reutilizada para cada etapa.
        $sql = "INSERT INTO adms_daman_budget_stages
                    (
                        adms_daman_budget_id,
                        adms_daman_stage_id,
                        budget_value,
                        sort_order,
                        status,
                        created_at
                    )
                VALUES
                    (
                        :adms_daman_budget_id,
                        :adms_daman_stage_id,
                        :budget_value,
                        :sort_order,
                        :status,
                        NOW()
                    )";


        $stmt = $connection->prepare($sql);


        // Percorrer todas as etapas enviadas pelo formulário.
        foreach ($stages as $stage) {

            // Orçamento ao qual a etapa pertence.
            $stmt->bindValue(
                ':adms_daman_budget_id',
                $budgetId,
                PDO::PARAM_INT
            );


            // Etapa selecionada no cadastro mestre.
            $stmt->bindValue(
                ':adms_daman_stage_id',
                (int) $stage['adms_daman_stage_id'],
                PDO::PARAM_INT
            );


            // Valor definido para esta etapa.
            $stmt->bindValue(
                ':budget_value',
                $stage['budget_value'],
                PDO::PARAM_STR
            );


            // Ordem definida automaticamente pelo formulário.
            $stmt->bindValue(
                ':sort_order',
                (int) $stage['sort_order'],
                PDO::PARAM_INT
            );


            // Etapa ativa.
            $stmt->bindValue(
                ':status',
                1,
                PDO::PARAM_INT
            );


            // Cadastrar a etapa atual.
            if (!$stmt->execute()) {
                return false;
            }
        }


        // Todas as etapas foram cadastradas.
        return true;
    }

    /**
 * Recuperar os dados da etapa do orçamento
 * necessários para o cadastro de itens.
 *
 * Também calcula:
 *
 * - Valor total da etapa
 * - Total dos itens já cadastrados
 * - Valor ainda disponível
 *
 * @param int $stageId ID da tabela adms_daman_budget_stages.
 * @return array|false
 */
public function getBudgetStageForItemCreation(
    int $stageId
): array|false {

    $sql = "SELECT

                -- ID da etapa específica deste orçamento
                adbs.id AS budget_stage_id,

                -- ID do orçamento
                adb.id AS budget_id,

                -- ID da etapa mestre
                ads.id AS stage_id,

                -- Obra
                adp.id AS project_id,
                adp.name AS project_name,

                -- Dados da etapa mestre
                ads.code AS stage_code,
                ads.name AS stage_name,

                -- Valor destinado a esta etapa
                adbs.budget_value AS stage_budget_value,

                -- Soma dos itens já cadastrados
                COALESCE(
                    SUM(adbi.budget_value),
                    0
                ) AS items_total,

                -- Valor ainda disponível na etapa
                (
                    adbs.budget_value
                    -
                    COALESCE(
                        SUM(adbi.budget_value),
                        0
                    )
                ) AS available_value

            FROM adms_daman_budget_stages AS adbs


            -- =================================================
            -- ETAPA MESTRE
            -- =================================================

            INNER JOIN adms_daman_stages AS ads
                ON ads.id = adbs.adms_daman_stage_id


            -- =================================================
            -- ORÇAMENTO
            -- =================================================

            INNER JOIN adms_daman_budgets AS adb
                ON adb.id = adbs.adms_daman_budget_id


            -- =================================================
            -- OBRA
            -- =================================================

            INNER JOIN adms_daman_projects AS adp
                ON adp.id = adb.adms_daman_project_id


            -- =================================================
            -- ITENS DA ETAPA
            -- =================================================
            --
            -- LEFT JOIN porque a etapa pode ainda não possuir
            -- nenhum item cadastrado.
            --
            LEFT JOIN adms_daman_budget_items AS adbi
                ON adbi.budget_stage_id = adbs.id
                AND adbi.status = 1


            WHERE adbs.id = :stage_id
            AND adbs.status = 1


            GROUP BY

                adbs.id,
                adb.id,
                ads.id,
                adp.id,
                adp.name,
                ads.code,
                ads.name,
                adbs.budget_value


            LIMIT 1";


    // Preparar a Query
    $stmt = $this->getConnection()->prepare($sql);


    // Vincular ID da etapa do orçamento
    $stmt->bindValue(
        ':stage_id',
        $stageId,
        PDO::PARAM_INT
    );


    // Executar
    $stmt->execute();


    // Recuperar resultado
    $result = $stmt->fetch(
        PDO::FETCH_ASSOC
    );


    // Retornar os dados ou false
    return $result ?: false;
}
}