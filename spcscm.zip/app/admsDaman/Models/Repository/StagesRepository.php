<?php

namespace App\admsDaman\Models\Repository;

use App\admsDaman\Models\Services\DbConnection;
use PDO;

class StagesRepository extends DbConnection
{
    public function getAllStages(): array
    {
        // QUERY para recuperar os registros do banco de dados
        $sql = 'SELECT id, code, name 
                FROM adms_daman_stages
                ORDER BY id ASC';

        // Preparar a QUERY
        $stmt = $this->getConnection()->prepare($sql);

        // Executar a QUERY
        $stmt->execute();

        // Ler os registros e retornar 
        return $stmt->fetchAll(PDO::FETCH_ASSOC);

    }
}