<?php

namespace App\admsDaman\Models\Repository;

use App\admsDaman\Models\Services\DbConnection;
use PDO;

class BudgetRepository extends DbConnection
{

    public function getAllBudgets(): array
    {
        // QUERY para recuperar os registros do banco de dados
        $sql = 'SELECT adb.id, adb.adms_daman_project_id, adb.total_budget, adb.type, adb.created_by, adb.approved_by, adb.created_at,
                adp.name AS project_name,
                adu_created.name AS created_by_name,
                adu_approved_by.name AS approved_by_name
                FROM adms_daman_budgets AS adb
                INNER JOIN adms_daman_projects AS adp ON adb.adms_daman_project_id = adp.id
                INNER JOIN adms_daman_users AS adu_created  ON adu_created.id = adb.created_by 
                LEFT JOIN adms_daman_users AS adu_approved_by  ON adu_approved_by.id = adb.approved_by 
                ORDER BY id DESC';

        // Preparar a Query
        $stmt = $this->getConnection()->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getStagesByBudget(int $budgetId): array
    {
        $sql = "SELECT 
                adbs.id AS budget_stage_id,
                adbs.adms_daman_budget_id,
                adbs.adms_daman_stage_id,
                ads.code,
                ads.name,
                adbs.budget_value,
                adbs.sort_order,
                adbs.status,
                adbs.created_at,
                adbs.updated_at
            FROM adms_daman_budget_stages AS adbs
            INNER JOIN adms_daman_stages AS ads ON adbs.adms_daman_stage_id = ads.id
            WHERE adbs.adms_daman_budget_id = :budget_id
            AND adbs.status = 1
            ORDER BY adbs.sort_order ASC";

        $stmt = $this->getConnection()->prepare($sql);

        $stmt->bindValue(':budget_id', $budgetId, PDO::PARAM_INT);

        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getItemsByStage(int $stageId): array
    {
        $sql = "SELECT
                adbi.id,
                adbi.budget_stage_id,
                adbi.code,
                adbi.description,
                adbi.adms_daman_measurement_units_id,
                adbi.quantity,
                adbi.unit_price,
                adbi.budget_value,
                adbi.sort_order,
                adbi.status,

                admu.name AS measurement_unit_name

            FROM adms_daman_budget_items AS adbi

            INNER JOIN adms_daman_measurement_units AS admu
                ON admu.id = adbi.adms_daman_measurement_units_id

            WHERE adbi.budget_stage_id = :stage_id
            AND adbi.status = 1

            ORDER BY adbi.sort_order ASC";

        $stmt = $this->getConnection()->prepare($sql);

        $stmt->bindValue(':stage_id', $stageId, PDO::PARAM_INT);

        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Cadastrar um novo orçamento.
     *
     * @param array $data Dados recebidos do formulário.
     * @return int|false ID do orçamento cadastrado ou false em caso de erro.
     */
    public function createBudget(array $data): int|false
    {
        // Recuperar a conexão uma única vez.
        $connection = $this->getConnection();


        // Query responsável por cadastrar o orçamento.
        $sql = "INSERT INTO adms_daman_budgets
                (
                    adms_daman_project_id,
                    total_budget,
                    type,
                    created_by,
                    approved_by,
                    approved_at,
                    created_at
                )
            VALUES
                (
                    :adms_daman_project_id,
                    :total_budget,
                    :type,
                    :created_by,
                    NULL,
                    NULL,
                    NOW()
                )";


        // Preparar a query.
        $stmt = $connection->prepare($sql);


        // Obra.
        $stmt->bindValue(
            ':adms_daman_project_id',
            (int) $data['adms_daman_project_id'],
            PDO::PARAM_INT
        );


        // Valor total do orçamento.
        //
        // Para DECIMAL prefiro enviar como string para o banco.
        $stmt->bindValue(
            ':total_budget',
            $data['total_budget'],
            PDO::PARAM_STR
        );


        // Todo orçamento recém-cadastrado começa como rascunho.
        $stmt->bindValue(
            ':type',
            'draft',
            PDO::PARAM_STR
        );


        // Usuário que está cadastrando.
        //
        // No formulário ele chega como adms_daman_user_id,
        // porém no banco a coluna se chama created_by.
        $stmt->bindValue(
            ':created_by',
            (int) $_SESSION['user_id'],
            PDO::PARAM_INT
        );


        // Executar o cadastro.
        if (!$stmt->execute()) {
            return false;
        }


        // Retornar o ID do orçamento recém-cadastrado.
        return (int) $connection->lastInsertId();
    }
}
