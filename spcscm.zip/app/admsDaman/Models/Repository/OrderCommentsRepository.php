<?php

namespace App\admsDaman\Models\Repository;

use App\admsDaman\Helpers\GenerateLog;
use App\admsDaman\Models\Services\DbConnection;
use Exception;
use PDO;

class OrderCommentsRepository extends DbConnection
{
    public function getComment(int $orderId): string|array
    {
        $sql = "SELECT adoc.id, adoc.adms_daman_order_id, adoc.adms_daman_user_id, adoc.type, adoc.action, adoc.field, adoc.old_value, adoc.new_value, adoc.adms_daman_order_item_id, adoc.comment, adoc.created_at,
        
        adu.name AS user_buyer, adu_approved.name AS user_approved
        FROM adms_daman_order_comments AS adoc
        INNER JOIN adms_daman_users AS adu ON adu.id=adoc.adms_daman_user_id
        LEFT JOIN adms_daman_users AS adu_approved ON adu_approved.id = adoc.adms_daman_approved_by 
        WHERE adoc.adms_daman_order_id = :adms_daman_order_id
        ORDER BY id DESC";

        $stmt = $this->getConnection()->prepare($sql);

        $stmt->bindValue(':adms_daman_order_id', $orderId, PDO::PARAM_INT);

        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
 * Registrar histórico/comentários do pedido.
 *
 * Pode registrar:
 * - alteração de dados do pedido;
 * - alteração de dados de itens;
 * - inclusão de novo item.
 */
public function insertMultipleComments(array $changes, $itemNewId = null): void
{
    if (empty($changes)) {
        return;
    }

    $sql = "INSERT INTO adms_daman_order_comments
        (
            adms_daman_order_id,
            adms_daman_user_id,
            type,
            action,
            field,
            old_value,
            new_value,
            adms_daman_order_item_id,
            comment,
            created_at
        )
        VALUES ";

    $values = [];
    $params = [];

    foreach ($changes as $index => $change) {

        /*
         * ID do item relacionado ao comentário/histórico.
         *
         * Alteração de item existente:
         * usa item_id vindo de $change.
         *
         * Inclusão de novo item:
         * usa o ID recém-gerado ($itemNewId).
         *
         * Alteração diretamente no pedido:
         * pode ficar NULL.
         */
        $itemId = $change['item_id'] ?? null;

        if (
            ($change['action'] ?? null) === 'add_item'
            && $itemNewId !== null
        ) {
            $itemId = $itemNewId;
        }

        $values[] = "(
            :order_id_$index,
            :user_id_$index,
            :type_$index,
            :action_$index,
            :field_$index,
            :old_value_$index,
            :new_value_$index,
            :item_id_$index,
            :comment_$index,
            NOW()
        )";

        $params[":order_id_$index"] = $change['order_id'];
        $params[":user_id_$index"] = $change['user_id'];

        $params[":type_$index"] = $change['type'] ?? 'auto';
        $params[":action_$index"] = $change['action'];

        $params[":field_$index"] = $change['field'] ?? null;
        $params[":old_value_$index"] = $change['old_value'] ?? null;
        $params[":new_value_$index"] = $change['new_value'] ?? null;

        $params[":item_id_$index"] = $itemId;

        $params[":comment_$index"] = $change['comment'] ?? null;
    }

    $sql .= implode(', ', $values);

    $stmt = $this->getConnection()->prepare($sql);
    $stmt->execute($params);
}

    /**
     * Metodo para comentar automáticamente no pedido ao gerar uma compra.
     */
    public function createAutomaticOrderPurchased(array $data): bool
    {
        try {
            $sql = "INSERT INTO adms_daman_order_comments  (adms_daman_order_id, adms_daman_user_id, adms_daman_approved_by, type, action, created_at)
        VALUES (:adms_daman_order_id, :adms_daman_user_id, :adms_daman_approved_by, :type, :action, :created_at)";

            // Preparar a QUERY
            $stmt = $this->getConnection()->prepare($sql);

            // Substituir os links da QUERY pelo valor
            $stmt->bindValue(':adms_daman_order_id', $data['adms_daman_order_id'], PDO::PARAM_INT);
            $stmt->bindValue(':adms_daman_user_id', $data['adms_daman_user_id'], PDO::PARAM_INT);
            $stmt->bindValue(':adms_daman_approved_by', $_SESSION['user_id'], PDO::PARAM_INT);
            $stmt->bindValue(':type', 'auto', PDO::PARAM_STR);
            $stmt->bindValue(':action', 'purchased_in', PDO::PARAM_STR);
            $stmt->bindValue(':created_at', date("Y-m-d H:i:s"));

            // Executar a QUERY
            $stmt->execute();

            // Verificar o número de linhas afetadas
            if ($stmt->rowCount() > 0) {
                return true;
            } else {

                // Chamar o método para salvar o log
                GenerateLog::generateLog("error", "Comentário não inserido.", ['id_pedido' => $data['adms_daman_order_id']]);

                return false;
            }
        } catch (Exception $e) {
            // Chamar o método para salvar o log
            GenerateLog::generateLog("error", "Comentário não inserido.", ['name' => $_SESSION['user_name'], 'error' => $e->getMessage()]);

            return false;
        }
    }

    /**
     * Metodo para mudar status automático da cotação, de pending para aproved ou rejected.
     */
    public function createAutomaticOrderRejected(array $data): bool
    {
        try {
            $sql = "INSERT INTO adms_daman_order_comments  (adms_daman_order_id, adms_daman_user_id, type, action, comment, created_at)
        VALUES (:adms_daman_order_id, :adms_daman_user_id, :type, :action, :comment, :created_at)";

            $comment = "Solicitação de autorização para cotação N° " . $data['id'] . " Rejeitada, motivo: " . $data['new_rejection_reason'];
            // Preparar a QUERY
            $stmt = $this->getConnection()->prepare($sql);

            // Substituir os links da QUERY pelo valor
            $stmt->bindValue(':adms_daman_order_id', $data['adms_daman_order_id'], PDO::PARAM_INT);
            $stmt->bindValue(':adms_daman_user_id', $_SESSION['user_id'], PDO::PARAM_INT);
            $stmt->bindValue(':type', 'auto', PDO::PARAM_STR);
            $stmt->bindValue(':action', 'rejected', PDO::PARAM_STR);
            $stmt->bindValue(':comment', $comment, PDO::PARAM_STR);
            $stmt->bindValue(':created_at', date("Y-m-d H:i:s"));

            // Executar a QUERY
            $stmt->execute();

            // Verificar o número de linhas afetadas
            if ($stmt->rowCount() > 0) {
                return true;
            } else {

                // Chamar o método para salvar o log
                GenerateLog::generateLog("error", "Comentário não inserido.", ['id_pedido' => $data['adms_daman_order_id']]);

                return false;
            }
        } catch (Exception $e) {
            // Chamar o método para salvar o log
            GenerateLog::generateLog("error", "Comentário não inserido.", ['name' => $_SESSION['user_name'], 'error' => $e->getMessage()]);

            return false;
        }
    }
}