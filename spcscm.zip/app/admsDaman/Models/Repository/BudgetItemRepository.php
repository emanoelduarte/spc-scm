<?php

declare(strict_types=1);

namespace App\admsDaman\Models\Repository;

use App\admsDaman\Models\Services\DbConnection;
use PDO;

/**
 * Repository responsável pelos itens
 * das etapas dos orçamentos.
 */
class BudgetItemRepository extends DbConnection
{
    /**
     * Recuperar a próxima ordem de classificação
     * para um item dentro de uma etapa do orçamento.
     *
     * Exemplo:
     *
     * Etapa Fundação:
     *
     * Item 1 -> sort_order = 1
     * Item 2 -> sort_order = 2
     *
     * O próximo item receberá:
     *
     * sort_order = 3
     *
     * @param int $budgetStageId ID da etapa do orçamento.
     * @return int Próximo sort_order.
     */
    public function getNextSortOrder(
        int $budgetStageId
    ): int {

        // =====================================================
        // CONSULTAR MAIOR SORT_ORDER DA ETAPA
        // =====================================================

        $sql = "SELECT
                    COALESCE(
                        MAX(sort_order),
                        0
                    ) + 1 AS next_sort_order

                FROM adms_daman_budget_items

                WHERE budget_stage_id = :budget_stage_id";


        // Preparar a Query
        $stmt = $this->getConnection()->prepare($sql);


        // Vincular o ID da etapa
        $stmt->bindValue(
            ':budget_stage_id',
            $budgetStageId,
            PDO::PARAM_INT
        );


        // Executar
        $stmt->execute();


        // Recuperar resultado
        $result = $stmt->fetch(
            PDO::FETCH_ASSOC
        );


        // Caso não exista nenhum item,
        // COALESCE fará o primeiro sort_order ser 1.
        return (int) (
            $result['next_sort_order']
            ?? 1
        );
    }


    /**
     * Cadastrar um novo item na etapa do orçamento.
     *
     * @param array $data Dados do item.
     * @return bool
     */
    public function createBudgetItem(
        array $data
    ): bool {

        // =====================================================
        // QUERY DE CADASTRO
        // =====================================================

        $sql = "INSERT INTO adms_daman_budget_items
                    (
                        budget_stage_id,
                        code,
                        description,
                        adms_daman_measurement_units_id,
                        quantity,
                        unit_price,
                        budget_value,
                        sort_order,
                        status,
                        created_at
                    )

                VALUES
                    (
                        :budget_stage_id,
                        :code,
                        :description,
                        :adms_daman_measurement_units_id,
                        :quantity,
                        :unit_price,
                        :budget_value,
                        :sort_order,
                        :status,
                        NOW()
                    )";


        // Preparar a Query
        $stmt = $this->getConnection()->prepare($sql);


        // =====================================================
        // VINCULAR OS DADOS
        // =====================================================


        // Etapa específica do orçamento
        $stmt->bindValue(
            ':budget_stage_id',
            (int) $data['budget_stage_id'],
            PDO::PARAM_INT
        );


        // Código do item
        //
        // Exemplo:
        // 01.01
        // 01.02
        // 02.01
        $stmt->bindValue(
            ':code',
            $data['code'],
            PDO::PARAM_STR
        );


        // Descrição do item
        $stmt->bindValue(
            ':description',
            $data['description'],
            PDO::PARAM_STR
        );


        // Unidade de medida
        $stmt->bindValue(
            ':adms_daman_measurement_units_id',
            (int) $data['adms_daman_measurement_units_id'],
            PDO::PARAM_INT
        );


        // Quantidade
        //
        // Como a coluna é DECIMAL, enviamos como string.
        $stmt->bindValue(
            ':quantity',
            $data['quantity'],
            PDO::PARAM_STR
        );


        // Preço unitário
        $stmt->bindValue(
            ':unit_price',
            $data['unit_price'],
            PDO::PARAM_STR
        );


        // Valor total orçado do item
        //
        // Este valor já deve chegar calculado pela Controller:
        //
        // quantity * unit_price
        //
        $stmt->bindValue(
            ':budget_value',
            $data['budget_value'],
            PDO::PARAM_STR
        );


        // Ordem do item dentro da etapa
        $stmt->bindValue(
            ':sort_order',
            (int) $data['sort_order'],
            PDO::PARAM_INT
        );


        // Item ativo
        $stmt->bindValue(
            ':status',
            1,
            PDO::PARAM_INT
        );


        // =====================================================
        // EXECUTAR CADASTRO
        // =====================================================

        return $stmt->execute();
    }
}