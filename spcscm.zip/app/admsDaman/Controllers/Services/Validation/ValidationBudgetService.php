<?php

namespace App\admsDaman\Controllers\Services\Validation;

use Rakit\Validation\Validator;

/**
 * Classe ValidationBudgetService
 * 
 *  @author Emanoel Duarte <emanoel.c.duarte@hotmail.com>
 * 
 * Esta classe é responsável por validar os dados de um formulário de cadastro e edição de orçamentos, aplicando regras de validação para criação e edição de orçamentos.
 * Ela utiliza o pacote `Rakit\Validation` para realizar as validações e inclui uma regra personalizada de unicidade em múltiplas colunas.
 * 
 * @package App\admsDaman\Controllers\Services\Validation
 */
class ValidationBudgetService
{
    /**
     * Validar os dados do formulário.
     * 
     * Este método valida os dados fornecidos no formulário de orçamento, aplicando diferentes regras dependendo se é uma criação ou edição de orçamento.
     * 
     * @param array $data Dados do formulário.
     * @return array Lista de erros. Se não houver erros, o array será vazio.
     */
    public function validate(array $data): array
    {

        // Criar o array que deve receber as mensagens de erro
        $errors = [];

        // Instaciar a classe de validação
        $validator = new Validator();

        $validator->addValidator('uniqueInColumns', new UniqueInColumnsRule());

        // Definir as regras de validação
        $rules = [];

        // Se não existir/estiver ausente o ID, significa que é uma criação (cadastrar)
        if (!isset($data['id'])) {
            $rules['adms_daman_project_id'] = 'required|integer|uniqueInColumns:adms_daman_budgets,adms_daman_project_id';
            $rules['total_budget'] = 'required|numeric';
            $rules['adms_daman_user_id'] = 'required|integer';//enviar usuário que está cadastrando
        } else {
            // Para edição, adicionar a validação de id e ignorar a própria categoria na verificação do nome
            $rules['id'] = 'required|integer';
            $rules['adms_daman_project_id'] = 'required|uniqueInColumns:adms_daman_budgets,adms_daman_project_id,' . $data['id'];
            $rules['total_budget'] = 'required';
        }

        // Definir mensagens personalizadas
        $messages = [
            'id:required'                                   => 'Dados inválidos.',
            'id:integer'                                    => 'Dados inválidos.',
            'adms_daman_project_id:required'                => 'Dados inválidos.',
            'adms_daman_project_id:integer'                 => 'Dados inválidos.',
            'total_budget:required'                         => 'O total do orçamento não pode ser vazio.',
            'total_budget:numeric'                          => 'O total do orçamento precisa ser um número.',
            'adms_daman_user_id:required'                   => 'Dados Inválidos.',
            'adms_daman_project_id:uniqueInColumns'         => 'Já existe um orçamento para esta obra.',
        ];

        // Criar o validador com os dados e regras fornecidas
        $validation = $validator->make($data, $rules);

        //Definir as mensagens de erro personalizadas
        $validation->setMessages($messages);

        // Validar dados
        $validation->validate();

        // Retornar os erros se houver
        if ($validation->fails()) {

            // Recuperar os erros
            $arrayErrors = $validation->errors();

            // Percorre o array de erros
            // firstofAll - obter a primeira mensagem de erro para cada campo validado.
            foreach ($arrayErrors->firstOfAll() as $key => $message) {
                $errors[$key] = $message;
            }
        }

        return $errors;
    }
}
?>