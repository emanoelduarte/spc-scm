<?php

declare(strict_types=1);

namespace App\admsDaman\Controllers\Services\Validation;

use Rakit\Validation\Validator;

/**
 * Classe ValidationBudgetStagesService
 *
 * Responsável por validar as etapas enviadas
 * no formulário de cadastro/edição do orçamento.
 *
 * Cada etapa deve possuir:
 *
 * - adms_daman_stage_id
 * - budget_value
 * - sort_order
 *
 * @package App\admsDaman\Controllers\Services\Validation
 */
class ValidationBudgetStagesService
{
    /**
     * Validar as etapas do orçamento.
     *
     * @param array $data Dados recebidos pelo formulário.
     * @return array Lista de erros.
     */
    public function validate(array $data): array
    {
        // Array que receberá todos os erros encontrados.
        $errors = [];


        // =====================================================
        // VERIFICAR SE EXISTEM ETAPAS
        // =====================================================
        //
        // O orçamento deve possuir pelo menos uma etapa.
        //
        if (
            !isset($data['stages'])
            || !is_array($data['stages'])
            || empty($data['stages'])
        ) {

            return [
                'É necessário cadastrar pelo menos uma etapa no orçamento.'
            ];
        }


        // =====================================================
        // INSTANCIAR O RAKIT
        // =====================================================

        $validator = new Validator();


        // =====================================================
        // REGRAS PARA CADA ETAPA
        // =====================================================

        $rules = [

            // ID vindo do select de etapas.
            // Deve existir e ser inteiro.
            'adms_daman_stage_id' => 'required|integer',

            // Valor destinado à etapa.
            // Pode ser inteiro ou decimal, porém não aceita letras.
            'budget_value' => 'required|numeric',

            // Ordem de exibição da etapa.
            'sort_order' => 'required|integer',
        ];


        // =====================================================
        // MENSAGENS PERSONALIZADAS
        // =====================================================

        $messages = [

            'adms_daman_stage_id:required'
                => 'O campo etapa é obrigatório.',

            'adms_daman_stage_id:integer'
                => 'A etapa selecionada é inválida.',


            'budget_value:required'
                => 'O valor da etapa é obrigatório.',

            'budget_value:numeric'
                => 'O valor da etapa precisa ser um número.',


            'sort_order:required'
                => 'A ordem da etapa é obrigatória.',

            'sort_order:integer'
                => 'A ordem da etapa é inválida.',
        ];


        // =====================================================
        // VALIDAR CADA ETAPA
        // =====================================================

        foreach ($data['stages'] as $index => $stage) {

            // Criar a validação somente para a etapa atual.
            $validation = $validator->make(
                $stage,
                $rules
            );


            // Definir mensagens personalizadas.
            $validation->setMessages($messages);


            // Executar validação.
            $validation->validate();


            // Caso existam erros nesta etapa.
            if ($validation->fails()) {

                // Recuperar os erros.
                $arrayErrors = $validation->errors();


                // Recuperar somente a primeira mensagem
                // de cada campo.
                foreach (
                    $arrayErrors->firstOfAll()
                    as $key => $message
                ) {

                    // Exemplo:
                    //
                    // stages.0.budget_value
                    // stages.1.adms_daman_stage_id
                    //
                    $errors[
                        "stages.$index.$key"
                    ] = $message;
                }
            }
        }


        // =====================================================
        // VERIFICAR ETAPAS DUPLICADAS
        // =====================================================
        //
        // O mesmo cadastro mestre de etapa não deve aparecer
        // duas vezes no mesmo orçamento.
        //
        // Exemplo inválido:
        //
        // Fundação  -> R$ 20.000
        // Estrutura -> R$ 30.000
        // Fundação  -> R$ 10.000
        //
        $stageIds = [];


        foreach ($data['stages'] as $index => $stage) {

            // Caso o ID não tenha sido informado,
            // o Rakit já tratará o erro.
            if (empty($stage['adms_daman_stage_id'])) {
                continue;
            }


            $stageId =
                (int) $stage['adms_daman_stage_id'];


            // Verificar se esta etapa já apareceu.
            if (in_array($stageId, $stageIds, true)) {

                $errors[
                    "stages.$index.adms_daman_stage_id_duplicate"
                ] = 'A mesma etapa não pode ser adicionada mais de uma vez ao orçamento.';

                continue;
            }


            // Registrar a etapa como utilizada.
            $stageIds[] = $stageId;
        }


        // =====================================================
        // REMOVER MENSAGENS DUPLICADAS
        // =====================================================
        //
        // Mantém o mesmo padrão utilizado no seu
        // ValidationOrderItemnsService.
        //
        $errors = array_values(
            array_unique($errors)
        );


        return $errors;
    }
}