<?php

declare(strict_types=1);

namespace App\admsDaman\Controllers\Services\Validation;

use Rakit\Validation\Validator;

/**
 * Classe ValidationBudgetItemsService
 *
 * Responsável por validar os dados do formulário
 * de cadastro dos itens de uma etapa do orçamento.
 *
 * @package App\admsDaman\Controllers\Services\Validation
 */
class ValidationBudgetItemsService
{
    /**
     * Validar os dados do item do orçamento.
     *
     * @param array $data Dados recebidos do formulário.
     * @return array Lista de erros. Retorna array vazio se não houver erros.
     */
    public function validate(array $data): array
    {
        // Array que receberá os erros encontrados
        $errors = [];


        // Instanciar o Rakit Validation
        $validator = new Validator();


        // =====================================================
        // REGRAS DE VALIDAÇÃO
        // =====================================================

        $rules = [

            // ID da etapa específica do orçamento
            'budget_stage_id' =>
                'required|integer',

            // Código do item dentro da etapa
            'code' =>
                'required',

            // Descrição do item
            'description' =>
                'required',

            // Unidade de medida
            'adms_daman_measurement_units_id' =>
                'required|integer',

            // Quantidade pode ser inteira ou decimal,
            // portanto usamos numeric.
            'quantity' =>
                'required|numeric',

            // Preço unitário também pode ser inteiro ou decimal.
            'unit_price' =>
                'required|numeric',
        ];


        // =====================================================
        // MENSAGENS PERSONALIZADAS
        // =====================================================

        $messages = [

            'budget_stage_id:required' =>
                'Dados da etapa inválidos.',

            'budget_stage_id:integer' =>
                'Dados da etapa inválidos.',


            'code:required' =>
                'O código do item é obrigatório.',


            'description:required' =>
                'A descrição do item é obrigatória.',


            'adms_daman_measurement_units_id:required' =>
                'A unidade de medida é obrigatória.',

            'adms_daman_measurement_units_id:integer' =>
                'A unidade de medida selecionada é inválida.',


            'quantity:required' =>
                'A quantidade é obrigatória.',

            'quantity:numeric' =>
                'A quantidade precisa ser um valor numérico.',


            'unit_price:required' =>
                'O preço unitário é obrigatório.',

            'unit_price:numeric' =>
                'O preço unitário precisa ser um valor numérico.',
        ];


        // =====================================================
        // CRIAR VALIDAÇÃO
        // =====================================================

        $validation = $validator->make(
            $data,
            $rules
        );


        // Definir mensagens personalizadas
        $validation->setMessages($messages);


        // Executar validação
        $validation->validate();


        // =====================================================
        // RECUPERAR ERROS DO RAKIT
        // =====================================================

        if ($validation->fails()) {

            $arrayErrors = $validation->errors();


            // Recuperar somente a primeira mensagem
            // de erro para cada campo.
            foreach (
                $arrayErrors->firstOfAll()
                as $key => $message
            ) {

                $errors[$key] = $message;
            }
        }


        // =====================================================
        // VALIDAÇÕES COMPLEMENTARES
        // =====================================================
        //
        // Essas validações são feitas somente caso os campos
        // tenham passado pela validação "numeric".
        //

        if (
            isset($data['quantity'])
            && is_numeric($data['quantity'])
            && (float) $data['quantity'] <= 0
        ) {

            $errors['quantity_value'] =
                'A quantidade precisa ser maior que zero.';
        }


        if (
            isset($data['unit_price'])
            && is_numeric($data['unit_price'])
            && (float) $data['unit_price'] <= 0
        ) {

            $errors['unit_price_value'] =
                'O preço unitário precisa ser maior que zero.';
        }


        // =====================================================
        // REMOVER MENSAGENS DUPLICADAS
        // =====================================================

        $errors = array_values(
            array_unique($errors)
        );


        return $errors;
    }
}