<?php

namespace App\admsDaman\Controllers\budgets;

use App\admsDaman\Controllers\Services\PageLayoutService;
use App\admsDaman\Controllers\Services\Validation\ValidationBudgetItemsService;
use App\admsDaman\Helpers\CSRFHelper;
use App\admsDaman\Models\Repository\BudgetItemRepository;
use App\admsDaman\Models\Repository\BudgetStageRepository;
use App\admsDaman\Models\Repository\MeasurementUnitsRepository;
use App\admsDaman\Views\Services\LoadViewService;

/**
 * Controller responsável pelo cadastro
 * dos itens das etapas do orçamento.
 */
class CreateBudgetItems
{
    /**
     * Dados enviados para a View.
     */
    private array|string|null $data = null;


    /**
     * ID da etapa específica do orçamento.
     *
     * IMPORTANTE:
     * Este ID pertence à tabela:
     *
     * adms_daman_budget_stages
     *
     * e não à tabela mestre adms_daman_stages.
     */
    private int $stageId;


    /**
     * Método principal.
     *
     * Recebe o ID da etapa do orçamento através da URL.
     *
     * Exemplo:
     *
     * /create-budget-items/6
     *
     * Neste caso:
     *
     * $stage_id = 6
     *
     * @param int $stage_id
     * @return void
     */
    public function index(int $stage_id): void
    {
        // Guardar o ID da etapa para utilizar
        // nos demais métodos da Controller.
        $this->stageId = $stage_id;


        // Receber os dados enviados pelo formulário.
        //
        // Caso não exista POST, retorna um array vazio.
        $this->data['form'] = filter_input_array(
            INPUT_POST, FILTER_UNSAFE_RAW) ?? [];


        // =====================================================
        // VERIFICAR SE O FORMULÁRIO FOI ENVIADO
        // =====================================================

        if (!empty($this->data['form'])) {


            // =================================================
            // VALIDAR CSRF
            // =================================================
            //
            // O token precisa ser o mesmo utilizado na View:
            //
            // form_create_budget_item
            //
            if (isset($this->data['form']['csrf_token']) && CSRFHelper::validateCSRFToken('form_create_budget_item', $this->data['form']['csrf_token'])) {

                // O ID da etapa que vale é SEMPRE o ID
                // recebido através da URL.
                //
                // Não devemos confiar em um possível
                // budget_stage_id enviado pelo navegador.
                $this->data['form']['budget_stage_id'] =
                    $this->stageId;


                // Chamar método responsável pelo cadastro.
                $this->addBudgetItem();

                return;
            }

            $this->viewBudgetItems();

            return;
        }


        // =====================================================
        // PRIMEIRO ACESSO À PÁGINA
        // =====================================================

        $this->viewBudgetItems();
    }


    /**
     * Cadastrar o item da etapa.
     *
     * Responsabilidades:
     *
     * 1. Validar dados com Rakit
     * 2. Calcular valor do item
     * 3. Verificar saldo da etapa
     * 4. Definir sort_order
     * 5. Cadastrar item
     *
     * @return void
     */
    private function addBudgetItem(): void
    {
        // =====================================================
        // VALIDAR OS CAMPOS
        // =====================================================

        $validationBudgetItemsService =
            new ValidationBudgetItemsService();


        $errors = $validationBudgetItemsService->validate( $this->data['form'] );


        // Caso existam erros de validação.
        if (!empty($errors)) {

            $_SESSION['error'] = implode('<br>', $errors);
            $this->viewBudgetItems();

            return;
        }


        // =====================================================
        // CALCULAR VALOR DO ITEM
        // =====================================================
        //
        // Não devemos confiar no budget_value enviado
        // pelo navegador.
        //
        // O backend calcula novamente:
        //
        // quantidade × preço unitário
        //
        $quantity = (float) $this->data['form']['quantity'];

        $unitPrice = (float) $this->data['form']['unit_price'];


        $budgetValue = $quantity * $unitPrice;

        // Guardar o valor calculado.
        //
        // number_format com "." mantém o padrão
        // utilizado pelo DECIMAL no MySQL.
        $this->data['form']['budget_value'] =
            number_format($budgetValue, 2, '.', '');


        // =====================================================
        // RECUPERAR DADOS DA ETAPA
        // =====================================================

        $budgetStageRepository =
            new BudgetStageRepository();


        $budgetStage =
            $budgetStageRepository
                ->getBudgetStageForItemCreation(
                    $this->stageId
                );


        // Caso a etapa não exista.
        if (!$budgetStage) {

            $_SESSION['error'] =
                "Etapa do orçamento não encontrada.";

            $this->viewBudgetItems();

            return;
        }


        // =====================================================
        // VERIFICAR SALDO DA ETAPA
        // =====================================================
        //
        // Exemplo:
        //
        // Valor da etapa      R$ 15.000
        // Itens existentes    R$ 10.000
        // Novo item           R$  6.000
        //
        // Total               R$ 16.000
        //
        // Resultado:
        //
        // BLOQUEAR.
        //
        $stageBudgetValue =
            (float) (
                $budgetStage['stage_budget_value']
                ?? 0
            );


        $itemsTotal =
            (float) (
                $budgetStage['items_total']
                ?? 0
            );


        $newItemsTotal =
            $itemsTotal + $budgetValue;


        // Não permitir que os itens ultrapassem
        // o valor definido para a etapa.
        if ($newItemsTotal > $stageBudgetValue) {

            $_SESSION['error'] =
                "Erro ao cadastrar item. "
                . "O valor do item excede o saldo "
                . "disponível da etapa.";

            $this->viewBudgetItems();

            return;
        }


        // =====================================================
        // RECUPERAR PRÓXIMO SORT_ORDER
        // =====================================================
        //
        // Exemplo:
        //
        // 02.01 -> sort_order 1
        // 02.02 -> sort_order 2
        //
        // Novo item:
        //
        // sort_order 3
        //
        $budgetItemRepository =
            new BudgetItemRepository();


        $this->data['form']['sort_order'] =
            $budgetItemRepository
                ->getNextSortOrder(
                    $this->stageId
                );


        // =====================================================
        // CADASTRAR ITEM
        // =====================================================

        $created =
            $budgetItemRepository
                ->createBudgetItem(
                    $this->data['form']
                );


        // Caso ocorra erro no cadastro.
        if (!$created) {

            $_SESSION['error'] =
                "Erro ao cadastrar o item do orçamento.";

            $this->viewBudgetItems();

            return;
        }


        // =====================================================
        // CADASTRO REALIZADO
        // =====================================================

        $_SESSION['success'] =
            "Item cadastrado com sucesso!";


        // -----------------------------------------------------
        // REDIRECIONAR
        // -----------------------------------------------------
        //
        // Por enquanto eu retornaria para a própria etapa.
        //
        // Isso permite cadastrar vários itens em sequência.
        //
        header(
            "Location: "
            . $_ENV['URL_ADM']
            . "create-budget-items/"
            . $this->stageId
        );

        exit;
    }


    /**
     * Carregar a visualização de criação
     * dos itens da etapa.
     *
     * @return void
     */
    private function viewBudgetItems(): void
    {
        // =====================================================
        // RECUPERAR A ETAPA DO ORÇAMENTO
        // =====================================================

        $budgetStageRepository =
            new BudgetStageRepository();


        $budgetStage =
            $budgetStageRepository
                ->getBudgetStageForItemCreation(
                    $this->stageId
                );


        // Caso alguém tente acessar diretamente:
        //
        // /create-budget-items/999999
        //
        // e a etapa não exista.
        if (!$budgetStage) {

            $_SESSION['error'] =
                "Etapa do orçamento não encontrada.";


            header(
                "Location: "
                . $_ENV['URL_ADM']
                . "list-budgets"
            );

            exit;
        }


        // Enviar dados da etapa para a View.
        $this->data['budgetStage'] =
            $budgetStage;


        // =====================================================
        // CARREGAR UNIDADES DE MEDIDA
        // =====================================================
        //
        // Usaremos o mesmo cadastro de unidades
        // que já é utilizado no CreateOrder.
        //
        $measurementUnitsRepository =
            new MeasurementUnitsRepository();


        $this->data['getAllMeasurementUnitsSelect'] =
            $measurementUnitsRepository
                ->getAllMeasurementUnitsSelect();


        // =====================================================
        // CONFIGURAÇÕES DA PÁGINA
        // =====================================================

        $pageElements = [

            'title_head' =>
                "Cadastrar Itens das Etapas",

            'menu' =>
                "list-budgets",

            'buttonPermissions' => [
                "ListBudgets"
            ],
        ];


        $pageLayoutService =
            new PageLayoutService();


        $this->data =
            array_merge(
                $this->data,
                $pageLayoutService
                    ->configurePageElements(
                        $pageElements
                    )
            );


        // =====================================================
        // CARREGAR VIEW
        // =====================================================

        $loadView =
            new LoadViewService(
                "admsDaman/Views/budgets/createbudgetitems",
                $this->data
            );


        $loadView->loadView();
    }
}