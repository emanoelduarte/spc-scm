<?php

namespace App\admsDaman\Controllers\budgets;

use App\admsDaman\Models\Repository\BudgetRepository;
use App\admsDaman\Views\Services\LoadViewService;
use App\admsDaman\Controllers\Services\PageLayoutService;


/**
 * Controller para listar Orçamentos
 *
 * Esta classe é responsável por recuperar e exibir uma lista de Orçamentos no sistema. Utiliza um repositório
 * para obter dados das Orçamentos
 * 
 * @author Emanoel <emanoel.c.duarte@hotmail.com>
 * @package App\admsDaman\Controllers\budgets;
 */
class ListBudgets
{

    /** @var array|string|null $data Recebe os dados que devem ser enviados para a View */
    private array|string|null $data = null;

    public function index(): void
    {
        $budgetRepository = new BudgetRepository();

        // Recupera os orçamentos
        $this->data['budgets'] = $budgetRepository->getAllBudgets();

        // Percorre os orçamentos
        foreach ($this->data['budgets'] as &$budget) {

            // Recupera as etapas do orçamento
            $budget['stages'] = $budgetRepository->getStagesByBudget(
                (int) $budget['id']
            );

            // Percorre as etapas
            foreach ($budget['stages'] as &$stage) {

                // Recupera os itens de cada etapa
                $stage['items'] = $budgetRepository->getItemsByStage(
                    (int) $stage['budget_stage_id']
                );
            }

            unset($stage);
        }

        unset($budget);

        $pageElements = [
            'title_head' => "Listar Orçamentos",
            'menu' => "list-budgets",
            'buttonPermissions' => ["CreateBudget"],
        ];

        $pageLayoutService = new PageLayoutService();
        $this->data = array_merge($this->data, $pageLayoutService->configurePageElements($pageElements));

        // Carregar a View
        $loadView = new LoadViewService("admsDaman/Views/budgets/list", $this->data);
        $loadView->loadView();
    }
}
