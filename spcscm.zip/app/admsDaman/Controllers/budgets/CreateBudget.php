<?php

namespace App\admsDaman\Controllers\budgets;

use App\admsDaman\Controllers\Services\PageLayoutService;
use App\admsDaman\Controllers\Services\Validation\ValidationBudgetService;
use App\admsDaman\Controllers\Services\Validation\ValidationBudgetStagesService;
use App\admsDaman\Helpers\CSRFHelper;
use App\admsDaman\Helpers\GenerateLog;
use App\admsDaman\Models\Repository\BudgetRepository;
use App\admsDaman\Models\Repository\BudgetStageRepository;
use App\admsDaman\Models\Repository\ProjectsRepository;
use App\admsDaman\Models\Repository\StagesRepository;
use App\admsDaman\Views\Services\LoadViewService;


class CreateBudget
{
    /** @var array|string|null $dados Recebe os dados que devem ser enviados para a VIEW */
    private array|string|null $data = null;

    /**
     * Método principal que gerencia a criação do orçamento.
     *
     * Este método é chamado para processar a criação de um novo orçamento. Ele verifica a validade do token CSRF,
     * valida os dados do formulário e, se tudo estiver correto, cria o orçamento. Caso contrário, carrega a
     * visualização de criação do orçamento com mensagens de erro.
     * 
     * @return void
     */
    public function index()
    {
        // Receber os dados do formulário de cadastro de orçamento
        $this->data['form'] = filter_input_array(INPUT_POST, FILTER_UNSAFE_RAW);

        // Acessa o IF se existir o CSRF e for válido o CSRF
        if (isset($this->data['form']['csrf_token']) and CSRFHelper::validateCSRFToken('form_create_budget', $this->data['form']['csrf_token'])) {

            // Chamar método cadastrar passando pelas validações necessárias
            // var_dump($this->data['form']);
            $this->addBudget();
        } else {
            // Chamar o método carregar a view
            $this->viewBudget();
        }
    }

    /**
     * Carregar a visualização de criação de orçamento.
     * 
     * Este método configura os dados necessários e carrega a view para a criação de um novo orçamento.
     * 
     * @return void
     */
    private function viewBudget(): void
    {
        // Instanciar o repositório para preencher os selects.
        $getAllStages = new StagesRepository();
        $this->data['getAllStages'] = $getAllStages->getAllStages();

        // Instanciar o repositório para preencher os selects.
        $getAllProjectsSelectActive = new ProjectsRepository();
        $this->data['getAllProjectsSelectActive'] = $getAllProjectsSelectActive->getAllProjectsSelectActive();

        $pageElements = [
            'title_head' => "Cadastrar Orçamento",
            'menu' => "list-budgets",
            'buttonPermissions' => ["ListBudgets"],
        ];

        $pageLayoutService = new PageLayoutService();
        $this->data = array_merge($this->data, $pageLayoutService->configurePageElements($pageElements));

        // Carregar a VIEW
        $loadView = new LoadViewService("admsDaman/Views/budgets/create", $this->data);
        $loadView->loadView();
    }

    /**
     * Adicionar um novo orçamento ao sistema.
     * 
     * Este método valida os dados do formulário usando a classe de validação `ValidationBudgetService` e,
     * se não houver erros, cria um orçamento no banco de dados usando o `BudgetRepository`. Caso contrário, ele
     * recarrega a visualização de criação com mensagens de erro.
     * 
     * @return void
     */
    private function addBudget(): void
    {
        // Instaciar a classe que valida os dados do formulário com Rakit
        $validationBudget = new ValidationBudgetService();
        $this->data['errors'] = $validationBudget->validate($this->data['form']);

        // Acessa o if quando existir algum campo com dados incorretos
        if (!empty($this->data['errors'])) {

            // Chamar o método carregar a view
            $this->viewBudget();

            return;
        }

        // Instaciar a classe que valida os dados do formulário com Rakit
        $validationBudget = new ValidationBudgetStagesService();
        $this->data['errors'] = $validationBudget->validate($this->data['form']);

        // Acessa o if quando existir algum campo com dados incorretos
        if (!empty($this->data['errors'])) {

            // Chamar o método carregar a view
            $this->viewBudget();

            return;
        }

        // Valor total distribuído entre as etapas
        $stagesSum = 0;

        foreach ($this->data['form']['stages'] ?? [] as $stage) {

            // Somar o valor de cada etapa
            $stagesSum += (float) ($stage['budget_value'] ?? 0);
        }


        // Verificar se o valor distribuído nas etapas
        // ultrapassa o valor total do orçamento
        if ($stagesSum > (float) $this->data['form']['total_budget']) {

            $_SESSION['error'] =
                "Erro ao cadastrar orçamento. "
                . "O valor das etapas excede o valor total do orçamento.";

            $this->viewBudget();

            return;
        }

        // Instanciar os repositories
        $budgetRepository = new BudgetRepository();

        $budgetStageRepository = new BudgetStageRepository();


        // Recuperar a conexão.
        //
        // Como DbConnection agora trabalha com conexão static,
        // os dois repositories estarão utilizando exatamente
        // esta mesma instância PDO.
        $connection = $budgetRepository->getConnection();


        try {

            // =====================================================
            // INICIAR TRANSAÇÃO
            // =====================================================

            $connection->beginTransaction();


            // =====================================================
            // CADASTRAR ORÇAMENTO
            // =====================================================

            $budgetId = $budgetRepository->createBudget(
                $this->data['form']
            );


            // Segurança adicional.
            if (!$budgetId) {

                throw new \RuntimeException(
                    'Não foi possível cadastrar o orçamento.'
                );
            }


            // =====================================================
            // CADASTRAR ETAPAS DO ORÇAMENTO
            // =====================================================

            $budgetStageRepository->createBudgetStages(
                $budgetId,
                $this->data['form']['stages']
            );


            // =====================================================
            // CONFIRMAR TRANSAÇÃO
            // =====================================================
            //
            // Só chegamos aqui se TODOS os INSERTS funcionaram.
            //
            $connection->commit();


            // =====================================================
            // SUCESSO
            // =====================================================

            $_SESSION['success'] =
                "Orçamento cadastrado com sucesso!";


            header(
                "Location: "
                    . $_ENV['URL_ADM']
                    . "list-budgets"
            );

            exit;
        } catch (\Throwable $err) {


            // =====================================================
            // DESFAZER TRANSAÇÃO
            // =====================================================

            if ($connection->inTransaction()) {

                $connection->rollBack();
            }


            // =====================================================
            // REGISTRAR O ERRO
            // =====================================================

            GenerateLog::generateLog(
                "error",
                "Erro ao cadastrar orçamento e suas etapas.",
                [
                    'error' => $err->getMessage()
                ]
            );


            // =====================================================
            // MENSAGEM AO USUÁRIO
            // =====================================================

            $_SESSION['error'] =
                "Erro ao cadastrar orçamento. "
                . "Nenhum dado foi salvo.";


            // Recarregar a tela mantendo os dados preenchidos.
            $this->viewBudget();

            return;
        }
    }
}
