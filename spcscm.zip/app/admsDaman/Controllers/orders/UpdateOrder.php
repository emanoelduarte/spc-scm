<?php

namespace App\admsDaman\Controllers\orders;

use App\admsDaman\Controllers\Services\OrderCommentService;
use App\admsDaman\Controllers\Services\PageLayoutService;
use App\admsDaman\Controllers\Services\Validation\ValidationOrderItemnsService;
use App\admsDaman\Controllers\Services\Validation\ValidationOrderService;
use App\admsDaman\Helpers\CSRFHelper;
use App\admsDaman\Helpers\GenerateLog;
use App\admsDaman\Models\Repository\CategoriesRepository;
use App\admsDaman\Models\Repository\OrderCommentsRepository;
use App\admsDaman\Models\Repository\OrdersRepository;
use App\admsDaman\Models\Repository\ProjectsRepository;
use App\admsDaman\Models\Repository\StatusRepository;
use App\admsDaman\Models\Repository\UsersAccessLevelsRepository;
use App\admsDaman\Views\Services\LoadViewService;
use App\admsDaman\Controllers\Services\ProjectAccessService;

/**
 * Controller responsável por editar um pedido.
 * 
 * @author Emanoel Duarte <emanoel.c.duarte@hotmail.com>
 * @package App\admsDaman\Controllers\orders
 */
class UpdateOrder
{

    /** @var array|string|null $data Dados que devem ser enviados para a VIEW */
    private array|string|null $data = null;

    /**
     * Editar o pedido.
     *
     * Este método gerencia o processo de edição de um pedido. Recebe os dados do formulário, valida o CSRF token e
     * a existência do pedido, e chama o método adequado para editar o pedido ou carregar a visualização de edição.
     *
     * @param int|string $id ID da pedido a ser editada.
     * 
     * @return void
     */
    public function index(int|string $id): void
    {
        $orderId = (int) $id;

        // Verificar se o ID do pedido é válido
        if (!$orderId) {
            GenerateLog::generateLog("error", "Pedido inválido", ['id' => $orderId]);
            $_SESSION['error'] = "Pedido não encontrado!";
            header("Location: {$_ENV['URL_ADM']}list-orders");
            return;
        }

        // Recuperar o pedido diretamente do banco
        $ordersRepository = new OrdersRepository();
        $currentOrder = $ordersRepository->getOrder($orderId);

        // Verificar se o pedido existe
        if (!$currentOrder) {
            GenerateLog::generateLog("error", "Pedido não encontrado", ['id' => $orderId]);
            $_SESSION['error'] = "Pedido não encontrado!";
            header("Location: {$_ENV['URL_ADM']}list-orders");
            return;
        }

        // Verificar se o usuário possui acesso à obra do pedido
        $projectAccessService = new ProjectAccessService();
        $userId = (int) $_SESSION['user_id'];
        $projectId = (int) $currentOrder['adms_daman_project_id'];

        if (!$projectAccessService->canAccessProject($userId, $projectId)) {
            GenerateLog::generateLog("error", "Acesso negado ao pedido", [
                'user_id' => $userId,
                'order_id' => $orderId,
                'project_id' => $projectId
            ]);

            $_SESSION['error'] = "Você não possui acesso a este pedido!";
            header("Location: {$_ENV['URL_ADM']}list-orders");
            return;
        }

        // Receber os dados do formulário
        $this->data['form'] = filter_input_array(INPUT_POST, FILTER_UNSAFE_RAW);

        // Verificar se recebeu um POST válido para edição
        if (
            isset($this->data['form']['csrf_token']) &&
            CSRFHelper::validateCSRFToken('form_update_order', $this->data['form']['csrf_token'])
        ) {
            // Garantir que o ID utilizado na edição seja o ID da rota
            $this->data['form']['id'] = $orderId;

            // Verificar se o usuário possui acesso à obra selecionada na edição
            $newProjectId = (int) ($this->data['form']['adms_daman_project_id'] ?? 0);

            if ($newProjectId && !$projectAccessService->canAccessProject($userId, $newProjectId)) {
                GenerateLog::generateLog("error", "Tentativa de alterar pedido para obra sem acesso", [
                    'user_id' => $userId,
                    'order_id' => $orderId,
                    'project_id' => $newProjectId
                ]);

                $_SESSION['error'] = "Você não possui acesso à obra selecionada!";
                header("Location: {$_ENV['URL_ADM']}list-orders");
                return;
            }

            // Editar o pedido
            $this->editOrder();
            return;
        }

        // Carregar os dados do pedido para edição
        $this->data['form'] = $currentOrder;
        $this->data['items'] = $ordersRepository->getItems($orderId);

        // Carregar a visualização para edição
        $this->viewUpdateOrder();
    }

    /**
     * Carregar a visualização para edição do pedido.
     *
     * Este método define o título do pedido e carrega a visualização de edição do pedido com os dados necessários.
     * 
     * @return void
     */
    private function viewUpdateOrder(): void
    {
        // Recuperar as obras que o usuário possui acesso
        $projectAccessService = new ProjectAccessService();
        $accessibleProjectIds = $projectAccessService->getAccessibleProjectIds((int) $_SESSION['user_id']);

        // Instanciar o repositório para preencher o select de obras
        $projectsRepository = new ProjectsRepository();
        $this->data['getAllProjectsSelect'] = $projectsRepository->getProjectsSelectByIds($accessibleProjectIds);

        // Instanciar o repositório para preencher os selects.
        $getAllStatusSelect = new StatusRepository();
        $this->data['getAllStatusSelect'] = $getAllStatusSelect->getAllStatusSelect();

        // Instanciar o repositório para preencher os selects.
        $getProjectSelect = new CategoriesRepository();
        $this->data['getAllCategoriesSelect'] = $getProjectSelect->getAllCategoriesSelect();

        // Instanciar o repositório para preencher os selects.
        $getMeasurementUnits = new OrdersRepository();
        $this->data['getAllMeasurementUnitsSelect'] = $getMeasurementUnits->getAllMeasurementUnitsSelect();

        // Solicitar do repositório de níveis de acesso do usuário os níveis do usuário logado para configurar o conteúdo que ele tem acesso para manipular nas edições do pedido
        $userAccessLevel = new UsersAccessLevelsRepository();
        $this->data['userAccessLevelsArray'] = $userAccessLevel->getUsersAccessLevels($_SESSION['user_id']);

        // Configurar os elementos da página
        $pageElements = [
            'title_head' => "Editar Pedido",
            'menu' => "list-orders",
            'buttonPermissions' => ["ListOrders", "ViewOrder", "PurchaseContent", "BuyerContent"],
        ];

        $pageLayoutService = new PageLayoutService();
        $this->data = array_merge($this->data, $pageLayoutService->configurePageElements($pageElements));

        // Carregar a VIEW
        $loadView = new LoadViewService("admsDaman/Views/orders/update", $this->data);
        $loadView->loadView();
    }

    /**
     * Editar pedido
     * 
     * Este método realiza a edição de um pedido existente no sistema. Ele valida os dados do formulário usando a
     * Classe `ValidationOrderService e ValidationOrderItemnsService`, exibe a view com os erros caso existam campos compdados incorretos,
     * Chama o repositório para atualizar o pedido e, depedendo do resultado, redireciona o pedido ou exibe
     * uma mensagem de erro
     * 
     * @return void
     */
    private function editOrder(): void
    {
        // Manter os itens do POST se houver erro de preenchimento
        $this->data['items'] = $this->data['form']['items'] ?? [];

        // Instanciar a classe validar os dados do formulário com Rakit
        $validationOrder = new ValidationOrderService();
        $this->data['errors'] = $validationOrder->validate($this->data['form']);

        // Acessa o IF quando existir o campo dados incorretos
        if (!empty($this->data['errors'])) {

            // Chama o método carregar a view
            $this->viewUpdateOrder();

            return;
        }

        // Instaciar a classe que valida os dados do formulário de itens do pedido com Rakit
        $validationItemns = new ValidationOrderItemnsService();
        $this->data['errors'] = $validationItemns->validate($this->data['form']);

        // Acessa o if quando existir algum campo com dados incorretos
        if (!empty($this->data['errors'])) {

            // Chamar o método carregar a view
            $this->viewUpdateOrder();

            return;
        }

        // Chamar serviço de comentários automáticos
        $commentService = new OrderCommentService();
        $changesArray = $commentService->logBatch($this->data['form']);

        // Instanciar o OrdersRepository para chamar o método que faz a edição do pedido
        $orderUpdate = new OrdersRepository();
        $result = $orderUpdate->updateOrder($this->data['form']);

        $newItemsMap = $result['newItemsMap'] ?? [];

        foreach ($changesArray as &$change) {

            if (
                $change['action'] === 'add_item' &&
                !empty($change['temp_id']) &&
                isset($newItemsMap[$change['temp_id']])
            ) {
                $change['item_id'] = $newItemsMap[$change['temp_id']];
            }
        }
        unset($change);

        // Verificar se o retorno teve dados ou foi array vazio
        if (!empty($changesArray)) {
            $orderComments = new OrderCommentsRepository();
            $orderComments->insertMultipleComments($changesArray);
        }

        // Acessa o IF se o repositório retornou TRUE
        if ($result) {
            // Criar a mensagem de sucesso ao editar
            $_SESSION['success'] = "Pedido editado com sucesso!";

            // Redirecionar o usuário para a página de visualizar Pedido
            header("Location: {$_ENV['URL_ADM']}view-order/{$this->data['form']['id']}");

            return;
        } else {
            // Criar a mensagem de erro ao tentar editar
            $this->data['errors'][] = "Pedido não editado!";

            // Chamar o método carregar a view
            $this->viewUpdateOrder();
        }
    }
}
